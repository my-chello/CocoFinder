import { StatusBar } from 'expo-status-bar';
import { useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, Text, View } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AuthProvider } from './src/context/AuthContext';
import { FavoritesProvider } from './src/context/FavoritesContext';
import { MessagesProvider } from './src/context/MessagesContext';
import { AppNavigator } from './src/navigation/AppNavigator';
import { palette } from './src/config/theme';
import {
  AppRole,
  AppViewMode,
  AuthProvider as AuthProviderType,
  clearAuthSession,
  clearSelectedRole,
  createAuthSession,
  getAuthSession,
  getSelectedRole,
  setAuthViewMode,
  setSelectedRole,
} from './src/lib/auth';
import { AdminModeScreen } from './src/screens/auth/AdminModeScreen';
import { completeOnboarding, hasCompletedOnboarding } from './src/lib/onboarding';
import { LoginScreen } from './src/screens/auth/LoginScreen';
import { RoleSelectionScreen } from './src/screens/auth/RoleSelectionScreen';
import { OnboardingScreen } from './src/screens/OnboardingScreen';
import { hasVendorProfile, saveVendorProfile, VendorProfileSetup } from './src/lib/vendorProfile';
import { VendorSetupScreen } from './src/screens/vendor/VendorSetupScreen';

export default function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [shouldShowOnboarding, setShouldShowOnboarding] = useState(false);
  const [selectedRole, setSelectedRoleState] = useState<AppRole | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authRole, setAuthRole] = useState<AppRole | null>(null);
  const [activeViewMode, setActiveViewMode] = useState<AppViewMode>('customer');
  const [hasCompletedVendorSetup, setHasCompletedVendorSetup] = useState(false);

  useEffect(() => {
    let isMounted = true;

    async function loadBootstrapState() {
      try {
        const [isComplete, storedRole, authSession] = await Promise.all([
          hasCompletedOnboarding(),
          getSelectedRole(),
          getAuthSession(),
        ]);
        const vendorProfileExists = await hasVendorProfile();

        if (!isMounted) {
          return;
        }

        setShouldShowOnboarding(!isComplete);
        setSelectedRoleState(storedRole);
        setIsAuthenticated(Boolean(authSession));
        setAuthRole(authSession?.role ?? null);
        setActiveViewMode(authSession?.viewMode ?? 'customer');
        setHasCompletedVendorSetup(vendorProfileExists);
      } catch {
        if (!isMounted) {
          return;
        }

        setShouldShowOnboarding(true);
        setSelectedRoleState(null);
        setIsAuthenticated(false);
        setAuthRole(null);
        setActiveViewMode('customer');
        setHasCompletedVendorSetup(false);
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    }

    void loadBootstrapState();

    return () => {
      isMounted = false;
    };
  }, []);

  async function handleCompleteOnboarding() {
    await completeOnboarding();
    setShouldShowOnboarding(false);
  }

  async function handleSelectRole(role: AppRole) {
    await setSelectedRole(role);
    setSelectedRoleState(role);
  }

  async function handleSelectAuthProvider(provider: AuthProviderType) {
    if (!selectedRole) {
      return;
    }

    await createAuthSession({
      role: selectedRole,
      provider,
      viewMode: selectedRole === 'admin' ? 'admin' : selectedRole,
    });
    setAuthRole(selectedRole);
    setActiveViewMode(selectedRole === 'admin' ? 'admin' : selectedRole);
    setIsAuthenticated(true);
  }

  async function handleBackToRoleSelection() {
    await clearSelectedRole();
    setSelectedRoleState(null);
  }

  async function handleSignOut() {
    await clearAuthSession();
    await clearSelectedRole();
    setSelectedRoleState(null);
    setAuthRole(null);
    setActiveViewMode('customer');
    setIsAuthenticated(false);
  }

  async function handleAdminViewModeChange(nextViewMode: AppViewMode) {
    await setAuthViewMode(nextViewMode);
    setActiveViewMode(nextViewMode);
  }

  async function handleCompleteVendorSetup(profile: VendorProfileSetup) {
    await saveVendorProfile(profile);
    setHasCompletedVendorSetup(true);
  }

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <AuthProvider value={{ authRole, activeViewMode }}>
          <FavoritesProvider>
            <MessagesProvider>
              <StatusBar style="light" />
              {isLoading ? (
                <View
                  style={{
                    flex: 1,
                    alignItems: 'center',
                    justifyContent: 'center',
                    backgroundColor: palette.ink,
                  }}
                >
                  <ActivityIndicator size="large" color={palette.mint} />
                </View>
              ) : shouldShowOnboarding ? (
                <OnboardingScreen onComplete={() => void handleCompleteOnboarding()} />
              ) : !selectedRole ? (
                <RoleSelectionScreen onSelectRole={(role) => void handleSelectRole(role)} />
              ) : !isAuthenticated ? (
                <LoginScreen
                  role={selectedRole}
                  onBack={() => void handleBackToRoleSelection()}
                  onSelectProvider={(provider) => void handleSelectAuthProvider(provider)}
                />
              ) : authRole === 'vendor' && !hasCompletedVendorSetup ? (
                <VendorSetupScreen
                  onComplete={(profile) => void handleCompleteVendorSetup(profile)}
                />
              ) : authRole === 'admin' && activeViewMode === 'admin' ? (
                <AdminModeScreen
                  onViewAsCustomer={() => void handleAdminViewModeChange('customer')}
                  onViewAsVendor={() => void handleAdminViewModeChange('vendor')}
                  onSignOut={() => void handleSignOut()}
                />
              ) : (
                <View style={{ flex: 1 }}>
                  {authRole === 'admin' && activeViewMode !== 'admin' ? (
                    <View
                      style={{
                        paddingHorizontal: 16,
                        paddingVertical: 10,
                        backgroundColor: '#111827',
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                      }}
                    >
                      <Text style={{ color: '#FFFFFF', fontSize: 13, fontWeight: '800' }}>
                        Admin preview: viewing as {activeViewMode}
                      </Text>
                      <Pressable onPress={() => void handleAdminViewModeChange('admin')}>
                        <Text style={{ color: '#7EE0B7', fontSize: 13, fontWeight: '800' }}>
                          Return to Admin
                        </Text>
                      </Pressable>
                    </View>
                  ) : null}
                  <AppNavigator />
                </View>
              )}
            </MessagesProvider>
          </FavoritesProvider>
        </AuthProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
