import { useEffect, useState } from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Alert, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useAuth } from '../../context/AuthContext';
import { palette } from '../../config/theme';
import { clearAuthSession, clearSelectedRole } from '../../lib/auth';
import { resetOnboarding } from '../../lib/onboarding';
import {
  clearVendorProfile,
  getVendorProfile,
  saveVendorProfile,
  type VendorProfileSetup,
} from '../../lib/vendorProfile';

const settings = [
  'Account details',
  'Location permissions',
  'Notification preferences',
  'Payment methods',
  'Privacy and GDPR controls',
] as const;

function VendorProfileEditor({
  initialProfile,
}: {
  initialProfile: VendorProfileSetup | null;
}) {
  const [isEditing, setIsEditing] = useState(false);
  const [profile, setProfile] = useState<VendorProfileSetup | null>(initialProfile);
  const [draft, setDraft] = useState<VendorProfileSetup | null>(initialProfile);

  useEffect(() => {
    setProfile(initialProfile);
    setDraft(initialProfile);
  }, [initialProfile]);

  if (!profile || !draft) {
    return (
      <View style={styles.vendorCard}>
        <Text style={styles.vendorEyebrow}>Vendor Profile</Text>
        <Text style={styles.vendorTitle}>Profile not available</Text>
        <Text style={styles.vendorCopy}>
          Complete vendor setup first to manage your business details here.
        </Text>
      </View>
    );
  }

  const missingFields = [
    !draft.businessName.trim() ? 'Business name' : null,
    !draft.logoSymbol.trim() ? 'Logo symbol' : null,
    !draft.category.trim() ? 'Category' : null,
    !draft.phone.trim() ? 'Phone' : null,
    !draft.openingHours.trim() ? 'Opening hours' : null,
    !draft.firstProductName.trim() ? 'First product' : null,
    !draft.firstProductPrice.trim() ? 'Price' : null,
    !draft.about.trim() ? 'About' : null,
  ].filter(Boolean) as string[];

  async function handleSave() {
    if (missingFields.length > 0) {
      Alert.alert('Complete vendor profile', `Please fill in: ${missingFields.join(', ')}`);
      return;
    }

    const profileToSave = draft;

    if (!profileToSave) {
      return;
    }

    await saveVendorProfile(profileToSave);
    setProfile(profileToSave);
    setIsEditing(false);
    Alert.alert('Profile saved', 'Your vendor profile has been updated.');
  }

  function updateField<K extends keyof VendorProfileSetup>(key: K, value: VendorProfileSetup[K]) {
    setDraft((current) => (current ? { ...current, [key]: value } : current));
  }

  return (
    <View style={styles.vendorCard}>
      <View style={styles.vendorHeaderRow}>
        <View style={styles.vendorHeaderCopy}>
          <Text style={styles.vendorEyebrow}>Vendor Profile</Text>
          <Text style={styles.vendorTitle}>Your vendor details</Text>
          <Text style={styles.vendorCopy}>
            Manage your business information, opening hours and first product.
          </Text>
        </View>

        <Pressable
          style={[styles.editButton, isEditing && styles.editButtonActive]}
          onPress={() => {
            if (isEditing) {
              setDraft(profile);
              setIsEditing(false);
              return;
            }

            setDraft(profile);
            setIsEditing(true);
          }}
        >
          <Text style={[styles.editButtonText, isEditing && styles.editButtonTextActive]}>
            {isEditing ? 'Cancel' : 'Edit'}
          </Text>
        </Pressable>
      </View>

      <View style={styles.vendorBlock}>
        <Text style={styles.blockLabel}>Business profile</Text>
        <View style={styles.vendorIdentityRow}>
          <View style={styles.vendorLogoBox}>
            <Text style={styles.vendorLogoText}>
              {isEditing ? draft.logoSymbol || '🛺' : profile.logoSymbol}
            </Text>
          </View>
          <View style={styles.vendorIdentityCopy}>
            <Text style={styles.blockTitle}>{profile.businessName}</Text>
            <Text style={styles.blockText}>{profile.category}</Text>
          </View>
        </View>

        {isEditing ? (
          <View style={styles.formStack}>
            <TextInput
              value={draft.businessName}
              onChangeText={(value) => updateField('businessName', value)}
              placeholder="Business name"
              placeholderTextColor="#8C9AAF"
              style={styles.profileInput}
            />
            <TextInput
              value={draft.logoSymbol}
              onChangeText={(value) => updateField('logoSymbol', value)}
              placeholder="Logo symbol"
              placeholderTextColor="#8C9AAF"
              style={styles.profileInput}
            />
            <TextInput
              value={draft.category}
              onChangeText={(value) => updateField('category', value)}
              placeholder="Category"
              placeholderTextColor="#8C9AAF"
              style={styles.profileInput}
            />
            <TextInput
              value={draft.phone}
              onChangeText={(value) => updateField('phone', value)}
              placeholder="Phone"
              placeholderTextColor="#8C9AAF"
              style={styles.profileInput}
            />
          </View>
        ) : (
          <Text style={styles.blockText}>
            Phone: {profile.phone}
          </Text>
        )}
      </View>

      <View style={styles.vendorBlock}>
        <Text style={styles.blockLabel}>About</Text>
        {isEditing ? (
          <TextInput
            value={draft.about}
            onChangeText={(value) => updateField('about', value)}
            placeholder="About your business"
            placeholderTextColor="#8C9AAF"
            style={[styles.profileInput, styles.profileTextArea]}
            multiline
            textAlignVertical="top"
          />
        ) : (
          <Text style={styles.blockText}>{profile.about}</Text>
        )}
      </View>

      <View style={styles.vendorBlock}>
        <Text style={styles.blockLabel}>Hours and product</Text>
        {isEditing ? (
          <View style={styles.formStack}>
            <TextInput
              value={draft.openingHours}
              onChangeText={(value) => updateField('openingHours', value)}
              placeholder="Opening hours"
              placeholderTextColor="#8C9AAF"
              style={styles.profileInput}
            />
            <View style={styles.formRow}>
              <TextInput
                value={draft.firstProductName}
                onChangeText={(value) => updateField('firstProductName', value)}
                placeholder="First product"
                placeholderTextColor="#8C9AAF"
                style={[styles.profileInput, styles.formRowMain]}
              />
              <TextInput
                value={draft.firstProductPrice}
                onChangeText={(value) => updateField('firstProductPrice', value)}
                placeholder="Price"
                placeholderTextColor="#8C9AAF"
                style={[styles.profileInput, styles.formRowSide]}
              />
            </View>
          </View>
        ) : (
          <Text style={styles.blockText}>
            Hours: {profile.openingHours}{'\n'}
            Product: {profile.firstProductName} · {profile.firstProductPrice}
          </Text>
        )}
      </View>

      {isEditing ? (
        <Pressable style={styles.saveButton} onPress={() => void handleSave()}>
          <Text style={styles.saveButtonText}>Save changes</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

export function ProfileScreen() {
  const { authRole, activeViewMode } = useAuth();
  const [vendorProfile, setVendorProfile] = useState<VendorProfileSetup | null>(null);

  const isVendorView =
    authRole === 'vendor' || (authRole === 'admin' && activeViewMode === 'vendor');

  useEffect(() => {
    let isMounted = true;

    async function loadVendorData() {
      const profile = await getVendorProfile();

      if (isMounted) {
        setVendorProfile(profile);
      }
    }

    void loadVendorData();

    return () => {
      isMounted = false;
    };
  }, []);

  async function handleResetOnboarding() {
    try {
      await clearAuthSession();
      await clearSelectedRole();
      await clearVendorProfile();
      await resetOnboarding();
      Alert.alert(
        'Intro flow reset',
        'Start de app opnieuw om onboarding, rolkeuze, login en vendor setup opnieuw te zien.'
      );
    } catch {
      Alert.alert('Reset mislukt', 'De onboarding kon niet worden gereset. Probeer het opnieuw.');
    }
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.content}>
        {isVendorView ? (
          <>
            <View style={styles.hero}>
              <Text style={styles.eyebrow}>Profile</Text>
              <Text style={styles.title}>Vendor settings</Text>
              <Text style={styles.copy}>
                This is your business profile. Review what customers see and keep it up to date.
              </Text>
            </View>

            <VendorProfileEditor initialProfile={vendorProfile} />

            <View style={styles.devCard}>
              <Text style={styles.devEyebrow}>Testing</Text>
              <Text style={styles.devTitle}>Replay onboarding</Text>
              <Text style={styles.devCopy}>
                Reset onboarding, role selection, login and vendor setup for a fresh test run.
              </Text>
              <Pressable style={styles.devButton} onPress={() => void handleResetOnboarding()}>
                <Text style={styles.devButtonText}>Reset intro flow</Text>
              </Pressable>
            </View>
          </>
        ) : (
          <>
            <View style={styles.hero}>
              <Text style={styles.eyebrow}>Profile</Text>
              <Text style={styles.title}>Customer settings</Text>
              <Text style={styles.copy}>
                Profile is the long-term home for account, permissions, and preferences.
              </Text>
            </View>

            <View style={styles.profileCard}>
              <Text style={styles.profileName}>Alex Customer</Text>
              <Text style={styles.profileSub}>Tracking favorite vendors across the city.</Text>

              <View style={styles.settingsList}>
                {settings.map((setting) => (
                  <View key={setting} style={styles.settingRow}>
                    <Text style={styles.settingText}>{setting}</Text>
                  </View>
                ))}
              </View>
            </View>

            <View style={styles.devCard}>
              <Text style={styles.devEyebrow}>Testing</Text>
              <Text style={styles.devTitle}>Replay onboarding</Text>
              <Text style={styles.devCopy}>
                Reset the first-run intro so you can preview the onboarding flow again.
              </Text>
              <Pressable style={styles.devButton} onPress={() => void handleResetOnboarding()}>
                <Text style={styles.devButtonText}>Reset onboarding</Text>
              </Pressable>
            </View>
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: palette.ink,
  },
  content: {
    padding: 20,
    gap: 14,
  },
  hero: {
    backgroundColor: palette.panel,
    borderRadius: 28,
    padding: 20,
  },
  eyebrow: {
    color: palette.mint,
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  title: {
    marginTop: 6,
    color: palette.cloud,
    fontSize: 28,
    fontWeight: '800',
  },
  copy: {
    marginTop: 10,
    color: '#B7C4D8',
    lineHeight: 21,
  },
  profileCard: {
    backgroundColor: '#F5F1E8',
    borderRadius: 28,
    padding: 20,
  },
  profileName: {
    color: palette.ink,
    fontSize: 24,
    fontWeight: '800',
  },
  profileSub: {
    marginTop: 8,
    color: '#475569',
    lineHeight: 21,
  },
  settingsList: {
    marginTop: 18,
    gap: 10,
  },
  settingRow: {
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    paddingHorizontal: 16,
    paddingVertical: 14,
  },
  settingText: {
    color: '#334155',
    fontWeight: '700',
  },
  vendorCard: {
    backgroundColor: palette.panel,
    borderRadius: 28,
    padding: 20,
    gap: 14,
  },
  vendorHeaderRow: {
    flexDirection: 'row',
    gap: 14,
    alignItems: 'flex-start',
  },
  vendorHeaderCopy: {
    flex: 1,
  },
  vendorEyebrow: {
    color: palette.mint,
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  vendorTitle: {
    marginTop: 6,
    color: palette.cloud,
    fontSize: 26,
    fontWeight: '800',
  },
  vendorCopy: {
    marginTop: 10,
    color: '#B7C4D8',
    lineHeight: 21,
  },
  editButton: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 999,
    paddingHorizontal: 14,
    paddingVertical: 10,
  },
  editButtonActive: {
    backgroundColor: '#FDE68A',
  },
  editButtonText: {
    color: palette.cloud,
    fontSize: 12,
    fontWeight: '800',
  },
  editButtonTextActive: {
    color: '#92400E',
  },
  vendorBlock: {
    backgroundColor: palette.panelAlt,
    borderRadius: 22,
    padding: 16,
    gap: 10,
  },
  blockLabel: {
    color: palette.mint,
    fontSize: 11,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  vendorIdentityRow: {
    flexDirection: 'row',
    gap: 14,
    alignItems: 'center',
  },
  vendorLogoBox: {
    width: 58,
    height: 58,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.10)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  vendorLogoText: {
    fontSize: 26,
  },
  vendorIdentityCopy: {
    flex: 1,
  },
  blockTitle: {
    color: palette.cloud,
    fontSize: 19,
    fontWeight: '800',
  },
  blockText: {
    color: '#D4DEEA',
    lineHeight: 21,
  },
  formStack: {
    gap: 10,
  },
  formRow: {
    flexDirection: 'row',
    gap: 10,
  },
  formRowMain: {
    flex: 1,
  },
  formRowSide: {
    width: 120,
  },
  profileInput: {
    minHeight: 54,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
    backgroundColor: 'rgba(255,255,255,0.08)',
    paddingHorizontal: 14,
    color: palette.cloud,
    fontSize: 15,
  },
  profileTextArea: {
    minHeight: 118,
    paddingTop: 14,
    paddingBottom: 14,
  },
  saveButton: {
    marginTop: 2,
    backgroundColor: palette.mint,
    borderRadius: 999,
    paddingVertical: 14,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#0F172A',
    fontSize: 14,
    fontWeight: '800',
  },
  devCard: {
    backgroundColor: '#F5F1E8',
    borderRadius: 28,
    padding: 20,
    gap: 10,
  },
  devEyebrow: {
    color: palette.orange,
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  devTitle: {
    color: palette.ink,
    fontSize: 24,
    fontWeight: '800',
  },
  devCopy: {
    color: '#475569',
    lineHeight: 21,
  },
  devButton: {
    marginTop: 4,
    alignSelf: 'flex-start',
    backgroundColor: palette.ink,
    borderRadius: 999,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  devButtonText: {
    color: palette.cloud,
    fontSize: 13,
    fontWeight: '800',
  },
});
