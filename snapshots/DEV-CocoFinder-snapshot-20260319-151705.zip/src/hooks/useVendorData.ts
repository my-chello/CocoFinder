import { useCallback, useMemo, useState } from 'react';
import { useFocusEffect } from '@react-navigation/native';
import { vendorTabRecords as baseVendorTabRecords, vendors as baseVendors } from '../data/mockVendors';
import { getVendorProfile, type VendorProfileSetup } from '../lib/vendorProfile';
import type { Vendor, VendorTabRecord } from '../types/vendor';

const EDITABLE_VENDOR_ID = 'vendor-cocero';

function mergeVendorProfileIntoRecords(
  records: VendorTabRecord[],
  profile: VendorProfileSetup | null
): VendorTabRecord[] {
  if (!profile) {
    return records;
  }

  return records.map((record) => {
    if (record.vendor.id !== EDITABLE_VENDOR_ID) {
      return record;
    }

    return {
      ...record,
      vendor: {
        ...record.vendor,
        businessName: profile.businessName,
        imageSymbol: profile.logoSymbol,
        category: profile.category,
        description: profile.about,
        operatingHours: profile.openingHours,
        phone: profile.phone,
        tags: [profile.category, profile.firstProductName, 'Vendor Setup'],
      },
      products: [
        {
          id: 'product-vendor-setup-primary',
          vendorId: record.vendor.id,
          name: profile.firstProductName,
          description: profile.about,
          price: 0,
          priceLabel: profile.firstProductPrice,
          isAvailable: true,
        },
        ...record.products.slice(1),
      ],
    };
  });
}

function mergeVendorProfileIntoVendors(vendors: Vendor[], profile: VendorProfileSetup | null): Vendor[] {
  if (!profile) {
    return vendors;
  }

  return vendors.map((vendor) => {
    if (vendor.id !== EDITABLE_VENDOR_ID) {
      return vendor;
    }

    return {
      ...vendor,
      name: profile.businessName,
      category: profile.category,
      description: profile.about,
      menu: [
        {
          id: 'menu-vendor-setup-primary',
          name: profile.firstProductName,
          priceLabel: profile.firstProductPrice,
        },
      ],
    };
  });
}

export function useVendorData() {
  const [vendorProfile, setVendorProfile] = useState<VendorProfileSetup | null>(null);

  const loadVendorProfile = useCallback(async () => {
    const profile = await getVendorProfile();
    setVendorProfile(profile);
  }, []);

  useFocusEffect(
    useCallback(() => {
      void loadVendorProfile();
    }, [loadVendorProfile])
  );

  const vendorTabRecords = useMemo(
    () => mergeVendorProfileIntoRecords(baseVendorTabRecords, vendorProfile),
    [vendorProfile]
  );
  const vendors = useMemo(
    () => mergeVendorProfileIntoVendors(baseVendors, vendorProfile),
    [vendorProfile]
  );

  return {
    vendorProfile,
    vendorTabRecords,
    vendors,
  };
}
