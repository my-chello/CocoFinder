import AsyncStorage from '@react-native-async-storage/async-storage';

export type VendorProfileSetup = {
  businessName: string;
  logoSymbol: string;
  category: string;
  phone: string;
  openingHours: string;
  firstProductName: string;
  firstProductPrice: string;
  about: string;
};

const VENDOR_PROFILE_STORAGE_KEY = 'cocofinder:vendor-profile';

export async function getVendorProfile(): Promise<VendorProfileSetup | null> {
  const storedValue = await AsyncStorage.getItem(VENDOR_PROFILE_STORAGE_KEY);

  if (!storedValue) {
    return null;
  }

  try {
    const parsed = JSON.parse(storedValue) as VendorProfileSetup;

    if (
      typeof parsed.businessName === 'string' &&
      typeof parsed.logoSymbol === 'string' &&
      typeof parsed.category === 'string' &&
      typeof parsed.phone === 'string' &&
      typeof parsed.openingHours === 'string' &&
      typeof parsed.firstProductName === 'string' &&
      typeof parsed.firstProductPrice === 'string' &&
      typeof parsed.about === 'string'
    ) {
      return parsed;
    }
  } catch {}

  return null;
}

export async function hasVendorProfile() {
  const profile = await getVendorProfile();

  return Boolean(
    profile &&
      profile.businessName.trim() &&
      profile.logoSymbol.trim() &&
      profile.category.trim() &&
      profile.phone.trim() &&
      profile.openingHours.trim() &&
      profile.firstProductName.trim() &&
      profile.firstProductPrice.trim() &&
      profile.about.trim()
  );
}

export async function saveVendorProfile(profile: VendorProfileSetup) {
  await AsyncStorage.setItem(VENDOR_PROFILE_STORAGE_KEY, JSON.stringify(profile));
}

export async function clearVendorProfile() {
  await AsyncStorage.removeItem(VENDOR_PROFILE_STORAGE_KEY);
}
