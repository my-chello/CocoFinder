import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Pressable, Text } from 'react-native';
import { VendorsScreen } from '../screens/customer/VendorsScreen';
import { VendorDetailScreen } from '../screens/customer/VendorDetailScreen';
import { palette } from '../config/theme';

export type VendorsStackParamList = {
  VendorsList: undefined;
  VendorDetail: { vendorId: string };
};

const Stack = createNativeStackNavigator<VendorsStackParamList>();

export function VendorsNavigator() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: palette.ink,
        },
        headerTintColor: palette.cloud,
        headerTitleStyle: {
          fontWeight: '800',
        },
        contentStyle: {
          backgroundColor: palette.ink,
        },
      }}
    >
      <Stack.Screen
        name="VendorsList"
        component={VendorsScreen}
        options={{ title: 'Vendors' }}
      />
      <Stack.Screen
        name="VendorDetail"
        component={VendorDetailScreen}
        options={({ navigation }) => ({
          title: 'Vendor Profile',
          headerLeft: () => (
            <Pressable
              onPress={() => {
                if (navigation.canGoBack()) {
                  navigation.goBack();
                  return;
                }

                navigation.navigate('VendorsList');
              }}
              style={{
                paddingVertical: 6,
                paddingRight: 12,
              }}
            >
              <Text
                style={{
                  color: palette.cloud,
                  fontSize: 14,
                  fontWeight: '800',
                }}
              >
                Back
              </Text>
            </Pressable>
          ),
        })}
      />
    </Stack.Navigator>
  );
}
