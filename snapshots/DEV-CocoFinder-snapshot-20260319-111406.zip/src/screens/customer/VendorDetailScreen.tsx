import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { palette } from '../../config/theme';
import { useFavorites } from '../../context/FavoritesContext';
import { vendorTabRecords } from '../../data/mockVendors';
import { VendorsStackParamList } from '../../navigation/VendorsNavigator';
import { conversationSummaries } from '../../data/mockMessages';

type VendorDetailRoute = RouteProp<VendorsStackParamList, 'VendorDetail'>;

function statusTone(status: string) {
  switch (status) {
    case 'active':
      return {
        backgroundColor: '#DCFCE7',
        color: '#166534',
      };
    case 'inactive':
      return {
        backgroundColor: '#FEF3C7',
        color: '#92400E',
      };
    case 'suspended':
      return {
        backgroundColor: '#FEE2E2',
        color: '#991B1B',
      };
    default:
      return {
        backgroundColor: '#E2E8F0',
        color: '#475569',
      };
  }
}

export function VendorDetailScreen() {
  const navigation = useNavigation<any>();
  const route = useRoute<VendorDetailRoute>();
  const { isFavorite, toggleFavorite } = useFavorites();
  const record = vendorTabRecords.find((item) => item.vendor.id === route.params.vendorId);

  if (!record) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.missingWrap}>
          <Text style={styles.missingTitle}>Vendor not found</Text>
          <Text style={styles.missingCopy}>
            The requested vendor profile could not be loaded.
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  const tone = statusTone(record.vendor.status);
  const conversation = conversationSummaries.find(
    (item) => item.vendorId === record.vendor.id
  );
  const vendorIsFavorite = isFavorite(record.vendor.id);

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.heroCard}>
          <View style={styles.heroTop}>
            <View style={styles.logoWrap}>
              <Text style={styles.logoText}>
                {record.vendor.imageSymbol ?? record.vendor.imageHint}
              </Text>
            </View>
            <View style={styles.identity}>
              <Text style={styles.vendorName}>{record.vendor.businessName}</Text>
              <Text style={styles.meta}>{record.vendor.category}</Text>
              <Text style={styles.distance}>{record.vendor.distanceKm} km away</Text>
            </View>
            <Pressable
              style={[
                styles.favoriteButton,
                vendorIsFavorite && styles.favoriteButtonActive,
              ]}
              onPress={() => toggleFavorite(record.vendor.id)}
            >
              <Text
                style={[
                  styles.favoriteButtonText,
                  vendorIsFavorite && styles.favoriteButtonTextActive,
                ]}
              >
                {vendorIsFavorite ? '❤️' : '♡'}
              </Text>
            </Pressable>
          </View>

          <Text style={styles.description}>{record.vendor.description}</Text>

          <View style={styles.badgeRow}>
            <View
              style={[
                styles.liveBadge,
                record.vendor.liveStatus === 'live' ? styles.liveBadgeOn : styles.liveBadgeOff,
              ]}
            >
              <Text
                style={[
                  styles.liveBadgeText,
                  record.vendor.liveStatus === 'live'
                    ? styles.liveBadgeTextOn
                    : styles.liveBadgeTextOff,
                ]}
              >
                {record.vendor.liveStatus === 'live' ? 'LIVE NOW' : 'NOT LIVE'}
              </Text>
            </View>
            <View style={[styles.statusBadge, { backgroundColor: tone.backgroundColor }]}>
              <Text style={[styles.statusText, { color: tone.color }]}>
                {record.vendor.status.toUpperCase()}
              </Text>
            </View>
          </View>

          {conversation ? (
            <Pressable
              style={styles.messageButton}
              onPress={() =>
                navigation.navigate('Messages', {
                  screen: 'ConversationDetail',
                  params: { conversationId: conversation.id },
                })
              }
            >
              <Text style={styles.messageButtonText}>Message vendor</Text>
            </Pressable>
          ) : null}
        </View>

        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>Hours</Text>
          <Text style={styles.sectionValue}>{record.vendor.operatingHours}</Text>
        </View>

        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>Business details</Text>
          <Text style={styles.sectionValue}>Phone: {record.vendor.phone}</Text>
          <Text style={styles.sectionSub}>
            Open status: {record.vendor.isOpen ? 'Open now' : 'Closed'}
          </Text>
          <Text style={styles.sectionSub}>Owner: {record.owner.fullName}</Text>
        </View>

        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>Latest location</Text>
          <Text style={styles.sectionValue}>
            {record.latestLocation
              ? `${record.latestLocation.latitude.toFixed(3)}, ${record.latestLocation.longitude.toFixed(3)}`
              : 'No GPS update yet'}
          </Text>
          <Text style={styles.sectionSub}>
            {record.latestLocation
              ? `Updated ${record.latestLocation.recordedAt}`
              : 'Waiting for vendor GPS ping'}
          </Text>
        </View>

        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>Product list with price</Text>
          {record.products.map((product) => (
            <View key={product.id} style={styles.productRow}>
              <View style={styles.productTextWrap}>
                <Text style={styles.productName}>{product.name}</Text>
                <Text style={styles.productDescription}>{product.description}</Text>
              </View>
              <View style={styles.productMeta}>
                <Text style={styles.productPrice}>{product.priceLabel}</Text>
                <Text
                  style={[
                    styles.productState,
                    { color: product.isAvailable ? '#166534' : '#991B1B' },
                  ]}
                >
                  {product.isAvailable ? 'Available' : 'Unavailable'}
                </Text>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: palette.ink,
  },
  content: {
    padding: 20,
    gap: 14,
  },
  missingWrap: {
    flex: 1,
    padding: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  missingTitle: {
    color: palette.cloud,
    fontSize: 24,
    fontWeight: '800',
  },
  missingCopy: {
    marginTop: 8,
    color: '#B7C4D8',
    textAlign: 'center',
    lineHeight: 21,
  },
  heroCard: {
    backgroundColor: palette.cloud,
    borderRadius: 28,
    padding: 18,
    gap: 14,
  },
  heroTop: {
    flexDirection: 'row',
    gap: 14,
  },
  logoWrap: {
    width: 72,
    height: 72,
    borderRadius: 20,
    backgroundColor: palette.panel,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoText: {
    color: palette.mint,
    fontSize: 24,
    fontWeight: '900',
  },
  identity: {
    flex: 1,
    justifyContent: 'center',
  },
  favoriteButton: {
    width: 46,
    height: 46,
    borderRadius: 999,
    backgroundColor: '#E2E8F0',
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'flex-start',
  },
  favoriteButtonActive: {
    backgroundColor: '#FDE68A',
  },
  favoriteButtonText: {
    color: '#475569',
    fontSize: 18,
    fontWeight: '800',
  },
  favoriteButtonTextActive: {
    color: '#B45309',
  },
  vendorName: {
    color: palette.ink,
    fontSize: 24,
    fontWeight: '800',
  },
  meta: {
    marginTop: 4,
    color: '#536072',
    fontSize: 14,
    fontWeight: '700',
  },
  distance: {
    marginTop: 6,
    color: '#0F172A',
    fontSize: 14,
    fontWeight: '800',
  },
  description: {
    color: '#324053',
    lineHeight: 22,
  },
  badgeRow: {
    flexDirection: 'row',
    gap: 8,
    flexWrap: 'wrap',
  },
  liveBadge: {
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 7,
  },
  liveBadgeOn: {
    backgroundColor: '#DCFCE7',
  },
  liveBadgeOff: {
    backgroundColor: '#E2E8F0',
  },
  liveBadgeText: {
    fontSize: 11,
    fontWeight: '800',
  },
  liveBadgeTextOn: {
    color: '#166534',
  },
  liveBadgeTextOff: {
    color: '#475569',
  },
  statusBadge: {
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 7,
  },
  statusText: {
    fontSize: 11,
    fontWeight: '800',
  },
  messageButton: {
    marginTop: 4,
    alignSelf: 'flex-start',
    backgroundColor: palette.ink,
    borderRadius: 999,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  messageButtonText: {
    color: palette.cloud,
    fontSize: 13,
    fontWeight: '800',
  },
  sectionCard: {
    backgroundColor: palette.cloud,
    borderRadius: 24,
    padding: 18,
    gap: 8,
  },
  sectionTitle: {
    color: palette.ink,
    fontSize: 16,
    fontWeight: '800',
  },
  sectionValue: {
    color: '#0F172A',
    fontSize: 14,
    fontWeight: '700',
  },
  sectionSub: {
    color: '#64748B',
    fontSize: 13,
    lineHeight: 20,
  },
  productRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 14,
  },
  productTextWrap: {
    flex: 1,
  },
  productName: {
    color: '#0F172A',
    fontSize: 15,
    fontWeight: '800',
  },
  productDescription: {
    marginTop: 4,
    color: '#475569',
    fontSize: 13,
    lineHeight: 18,
  },
  productMeta: {
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },
  productPrice: {
    color: '#0F172A',
    fontSize: 13,
    fontWeight: '800',
  },
  productState: {
    fontSize: 12,
    fontWeight: '700',
  },
});
