import { createContext, ReactNode, useContext, useMemo, useState } from 'react';
import { favoriteVendorIds as initialFavoriteVendorIds } from '../data/mockVendors';

type FavoritesContextValue = {
  favoriteVendorIds: string[];
  isFavorite: (vendorId: string) => boolean;
  toggleFavorite: (vendorId: string) => void;
};

const FavoritesContext = createContext<FavoritesContextValue | null>(null);

type FavoritesProviderProps = {
  children: ReactNode;
};

export function FavoritesProvider({ children }: FavoritesProviderProps) {
  const [favoriteVendorIds, setFavoriteVendorIds] = useState<string[]>(initialFavoriteVendorIds);

  const value = useMemo<FavoritesContextValue>(
    () => ({
      favoriteVendorIds,
      isFavorite: (vendorId: string) => favoriteVendorIds.includes(vendorId),
      toggleFavorite: (vendorId: string) => {
        setFavoriteVendorIds((current) =>
          current.includes(vendorId)
            ? current.filter((id) => id !== vendorId)
            : [...current, vendorId]
        );
      },
    }),
    [favoriteVendorIds]
  );

  return <FavoritesContext.Provider value={value}>{children}</FavoritesContext.Provider>;
}

export function useFavorites() {
  const context = useContext(FavoritesContext);

  if (!context) {
    throw new Error('useFavorites must be used within a FavoritesProvider.');
  }

  return context;
}
