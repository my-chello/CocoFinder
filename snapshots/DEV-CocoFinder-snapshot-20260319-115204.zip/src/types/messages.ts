export type MessageSenderRole = 'customer' | 'vendor';

export type ConversationSummary = {
  id: string;
  vendorId: string;
  customerUserId: string;
  vendorName: string;
  vendorCategory: string;
  vendorSymbol?: string;
  lastMessagePreview: string;
  lastMessageAt: string;
  lastMessageSortMinutesAgo: number;
  unreadCount: number;
  isVendorLive: boolean;
};

export type ChatMessage = {
  id: string;
  conversationId: string;
  senderRole: MessageSenderRole;
  senderName: string;
  body: string;
  sentAt: string;
};
