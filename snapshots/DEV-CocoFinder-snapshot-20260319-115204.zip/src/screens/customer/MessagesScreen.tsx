import { useMemo, useState } from 'react';
import { useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Swipeable } from 'react-native-gesture-handler';
import { palette } from '../../config/theme';
import { conversationSummaries } from '../../data/mockMessages';

export function MessagesScreen() {
  const navigation = useNavigation<any>();
  const [deletedConversationIds, setDeletedConversationIds] = useState<string[]>([]);
  const sortedConversations = useMemo(
    () =>
      conversationSummaries
        .filter((conversation) => !deletedConversationIds.includes(conversation.id))
        .sort(
        (left, right) => left.lastMessageSortMinutesAgo - right.lastMessageSortMinutesAgo
      ),
    [deletedConversationIds]
  );

  function confirmDelete(conversationId: string) {
    Alert.alert(
      'Gesprek verwijderen',
      'Weet je zeker dat je dit gesprek wilt verwijderen?',
      [
        {
          text: 'Annuleren',
          style: 'cancel',
        },
        {
          text: 'Verwijderen',
          style: 'destructive',
          onPress: () => {
            setDeletedConversationIds((current) => [...current, conversationId]);
          },
        },
      ]
    );
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.hero}>
          <Text style={styles.eyebrow}>Messages</Text>
          <Text style={styles.title}>Conversations with vendors</Text>
          <Text style={styles.copy}>
            Ask if a vendor is available, what they have in stock, and pick the thread back up
            anytime.
          </Text>
        </View>

        {sortedConversations.length > 0 ? (
          sortedConversations.map((thread) => (
            <Swipeable
              key={thread.id}
              overshootRight={false}
              renderRightActions={() => (
                <Pressable
                  style={styles.deleteAction}
                  onPress={() => confirmDelete(thread.id)}
                >
                  <Text style={styles.deleteActionText}>Verwijderen</Text>
                </Pressable>
              )}
            >
              <Pressable
                style={styles.threadCard}
                onPress={() =>
                  navigation.navigate('ConversationDetail', {
                    conversationId: thread.id,
                  })
                }
              >
                <View style={styles.threadTop}>
                  <View style={styles.threadIdentity}>
                    <View style={styles.threadSymbolWrap}>
                      <Text style={styles.threadSymbol}>
                        {thread.vendorSymbol ?? thread.vendorName[0]}
                      </Text>
                    </View>
                    <View style={styles.threadTextWrap}>
                      <Text style={styles.threadVendor}>{thread.vendorName}</Text>
                      <Text style={styles.threadMeta}>{thread.vendorCategory}</Text>
                    </View>
                  </View>
                  <View style={styles.threadRight}>
                    <Text style={styles.threadTime}>{thread.lastMessageAt}</Text>
                    {thread.unreadCount > 0 ? (
                      <View style={styles.unreadBadge}>
                        <Text style={styles.unreadText}>{thread.unreadCount}</Text>
                      </View>
                    ) : null}
                  </View>
                </View>

                <Text style={styles.threadMessage}>{thread.lastMessagePreview}</Text>

                <View style={styles.threadFooter}>
                  <Text style={styles.threadStatus}>
                    {thread.isVendorLive ? 'Live now' : 'Offline'}
                  </Text>
                  <Text style={styles.threadOpen}>Open chat</Text>
                </View>
              </Pressable>
            </Swipeable>
          ))
        ) : (
          <View style={styles.emptyCard}>
            <Text style={styles.emptyTitle}>Nog geen gesprekken gestart</Text>
            <Text style={styles.emptyCopy}>
              Start een gesprek met een vendor om hier je chatgeschiedenis terug te zien.
            </Text>
            <Pressable
              style={styles.emptyButton}
              onPress={() =>
                navigation.navigate('Vendors', {
                  screen: 'VendorsList',
                })
              }
            >
              <Text style={styles.emptyButtonText}>Bekijk vendors</Text>
            </Pressable>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: palette.ink,
  },
  content: {
    padding: 20,
    gap: 14,
  },
  hero: {
    backgroundColor: palette.panel,
    borderRadius: 28,
    padding: 20,
  },
  eyebrow: {
    color: palette.mint,
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  title: {
    marginTop: 6,
    color: palette.cloud,
    fontSize: 28,
    fontWeight: '800',
  },
  copy: {
    marginTop: 10,
    color: '#B7C4D8',
    lineHeight: 21,
  },
  threadCard: {
    backgroundColor: palette.panelAlt,
    borderRadius: 24,
    padding: 16,
    gap: 12,
  },
  deleteAction: {
    marginBottom: 14,
    borderRadius: 24,
    backgroundColor: '#DC2626',
    width: 118,
    alignItems: 'center',
    justifyContent: 'center',
  },
  deleteActionText: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '800',
  },
  threadTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
  },
  threadIdentity: {
    flex: 1,
    flexDirection: 'row',
    gap: 12,
  },
  threadSymbolWrap: {
    width: 48,
    height: 48,
    borderRadius: 15,
    backgroundColor: palette.cloud,
    alignItems: 'center',
    justifyContent: 'center',
  },
  threadSymbol: {
    fontSize: 20,
    fontWeight: '800',
  },
  threadTextWrap: {
    flex: 1,
    justifyContent: 'center',
  },
  threadVendor: {
    color: palette.cloud,
    fontSize: 17,
    fontWeight: '800',
  },
  threadMeta: {
    marginTop: 4,
    color: '#9FB0C8',
    fontSize: 12,
    fontWeight: '700',
  },
  threadRight: {
    alignItems: 'flex-end',
    gap: 8,
  },
  threadTime: {
    color: '#9FB0C8',
    fontSize: 12,
    fontWeight: '700',
  },
  unreadBadge: {
    minWidth: 22,
    height: 22,
    paddingHorizontal: 6,
    borderRadius: 999,
    backgroundColor: palette.mint,
    alignItems: 'center',
    justifyContent: 'center',
  },
  unreadText: {
    color: '#0F172A',
    fontSize: 11,
    fontWeight: '800',
  },
  threadMessage: {
    color: '#B7C4D8',
    lineHeight: 21,
  },
  threadFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  threadStatus: {
    color: palette.mint,
    fontSize: 12,
    fontWeight: '800',
  },
  threadOpen: {
    color: palette.cloud,
    fontSize: 12,
    fontWeight: '800',
  },
  emptyCard: {
    backgroundColor: palette.panelAlt,
    borderRadius: 24,
    padding: 20,
    gap: 12,
    alignItems: 'flex-start',
  },
  emptyTitle: {
    color: palette.cloud,
    fontSize: 20,
    fontWeight: '800',
  },
  emptyCopy: {
    color: '#B7C4D8',
    lineHeight: 21,
  },
  emptyButton: {
    marginTop: 4,
    backgroundColor: palette.mint,
    borderRadius: 999,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  emptyButtonText: {
    color: '#0F172A',
    fontSize: 13,
    fontWeight: '800',
  },
});
