import { SafeAreaView } from 'react-native-safe-area-context';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { palette } from '../../config/theme';
import { vendorTabRecords } from '../../data/mockVendors';

const settings = [
  'Account details',
  'Location permissions',
  'Notification preferences',
  'Payment methods',
  'Privacy and GDPR controls',
];

export function ProfileScreen() {
  const vendorRecord = vendorTabRecords[0];

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.hero}>
          <Text style={styles.eyebrow}>Profile</Text>
          <Text style={styles.title}>Customer settings</Text>
          <Text style={styles.copy}>
            Profile is the long-term home for account, permissions, and preferences.
          </Text>
        </View>

        <View style={styles.profileCard}>
          <Text style={styles.profileName}>Alex Customer</Text>
          <Text style={styles.profileSub}>Tracking favorite vendors across the city.</Text>

          <View style={styles.settingsList}>
            {settings.map((setting) => (
              <View key={setting} style={styles.settingRow}>
                <Text style={styles.settingText}>{setting}</Text>
              </View>
            ))}
          </View>
        </View>

        <View style={styles.vendorCard}>
          <Text style={styles.vendorEyebrow}>Vendor Workspace</Text>
          <Text style={styles.vendorTitle}>Register, set products, and go live</Text>
          <Text style={styles.vendorCopy}>
            This module implements the first-pass vendor stories inside the app so the
            business flow is visible before a separate vendor app exists.
          </Text>

          <View style={styles.vendorBlock}>
            <Text style={styles.blockLabel}>Business registration</Text>
            <Text style={styles.blockTitle}>{vendorRecord.vendor.businessName}</Text>
            <Text style={styles.blockText}>
              Category: {vendorRecord.vendor.category}{'\n'}
              Phone: {vendorRecord.vendor.phone}{'\n'}
              Status: {vendorRecord.vendor.status}
            </Text>
          </View>

          <View style={styles.vendorBlock}>
            <Text style={styles.blockLabel}>Products and prices</Text>
            {vendorRecord.products.map((product) => (
              <View key={product.id} style={styles.productRow}>
                <View style={styles.productTextWrap}>
                  <Text style={styles.productName}>{product.name}</Text>
                  <Text style={styles.productInfo}>{product.description}</Text>
                </View>
                <View style={styles.productMeta}>
                  <Text style={styles.productPrice}>{product.priceLabel}</Text>
                  <Text
                    style={[
                      styles.productState,
                      { color: product.isAvailable ? '#166534' : '#991B1B' },
                    ]}
                  >
                    {product.isAvailable ? 'Available' : 'Unavailable'}
                  </Text>
                </View>
              </View>
            ))}
          </View>

          <View style={styles.vendorBlock}>
            <Text style={styles.blockLabel}>Go Live</Text>
            <View style={styles.liveRow}>
              <View style={styles.liveSummary}>
                <Text style={styles.liveTitle}>
                  {vendorRecord.vendor.liveStatus === 'live' ? 'Currently live' : 'Not live'}
                </Text>
                <Text style={styles.liveInfo}>
                  Next area: {vendorRecord.vendor.nextArea}{'\n'}
                  Last location update: {vendorRecord.latestLocation?.recordedAt ?? 'No update'}
                </Text>
              </View>
              <View
                style={[
                  styles.liveBadge,
                  vendorRecord.vendor.liveStatus === 'live'
                    ? styles.liveBadgeOn
                    : styles.liveBadgeOff,
                ]}
              >
                <Text
                  style={[
                    styles.liveBadgeText,
                    vendorRecord.vendor.liveStatus === 'live'
                      ? styles.liveBadgeTextOn
                      : styles.liveBadgeTextOff,
                  ]}
                >
                  {vendorRecord.vendor.liveStatus === 'live' ? 'GO LIVE ON' : 'GO LIVE OFF'}
                </Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: palette.ink,
  },
  content: {
    padding: 20,
    gap: 14,
  },
  hero: {
    backgroundColor: palette.panel,
    borderRadius: 28,
    padding: 20,
  },
  eyebrow: {
    color: palette.mint,
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  title: {
    marginTop: 6,
    color: palette.cloud,
    fontSize: 28,
    fontWeight: '800',
  },
  copy: {
    marginTop: 10,
    color: '#B7C4D8',
    lineHeight: 21,
  },
  profileCard: {
    backgroundColor: '#F5F1E8',
    borderRadius: 28,
    padding: 20,
  },
  profileName: {
    color: palette.ink,
    fontSize: 24,
    fontWeight: '800',
  },
  profileSub: {
    marginTop: 8,
    color: '#475569',
    lineHeight: 21,
  },
  settingsList: {
    marginTop: 18,
    gap: 10,
  },
  settingRow: {
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    paddingHorizontal: 16,
    paddingVertical: 14,
  },
  settingText: {
    color: '#334155',
    fontWeight: '700',
  },
  vendorCard: {
    backgroundColor: palette.panel,
    borderRadius: 28,
    padding: 20,
    gap: 14,
  },
  vendorEyebrow: {
    color: palette.mint,
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  vendorTitle: {
    color: palette.cloud,
    fontSize: 26,
    fontWeight: '800',
  },
  vendorCopy: {
    color: '#B7C4D8',
    lineHeight: 21,
  },
  vendorBlock: {
    backgroundColor: palette.panelAlt,
    borderRadius: 22,
    padding: 16,
    gap: 10,
  },
  blockLabel: {
    color: palette.mint,
    fontSize: 11,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  blockTitle: {
    color: palette.cloud,
    fontSize: 19,
    fontWeight: '800',
  },
  blockText: {
    color: '#D4DEEA',
    lineHeight: 21,
  },
  productRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 12,
  },
  productTextWrap: {
    flex: 1,
  },
  productName: {
    color: palette.cloud,
    fontWeight: '800',
  },
  productInfo: {
    marginTop: 4,
    color: '#B7C4D8',
    fontSize: 12,
    lineHeight: 18,
  },
  productMeta: {
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },
  productPrice: {
    color: palette.cloud,
    fontSize: 12,
    fontWeight: '800',
  },
  productState: {
    fontSize: 11,
    fontWeight: '800',
  },
  liveRow: {
    flexDirection: 'row',
    gap: 12,
    alignItems: 'stretch',
  },
  liveSummary: {
    flex: 1,
  },
  liveTitle: {
    color: palette.cloud,
    fontSize: 17,
    fontWeight: '800',
  },
  liveInfo: {
    marginTop: 6,
    color: '#B7C4D8',
    lineHeight: 20,
  },
  liveBadge: {
    minWidth: 104,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 18,
    paddingHorizontal: 12,
  },
  liveBadgeOn: {
    backgroundColor: '#DCFCE7',
  },
  liveBadgeOff: {
    backgroundColor: '#FEE2E2',
  },
  liveBadgeText: {
    fontSize: 11,
    fontWeight: '900',
    textAlign: 'center',
  },
  liveBadgeTextOn: {
    color: '#166534',
  },
  liveBadgeTextOff: {
    color: '#991B1B',
  },
});
