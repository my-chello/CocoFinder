import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { palette } from '../../config/theme';
import { useFavorites } from '../../context/FavoritesContext';
import { vendorTabRecords } from '../../data/mockVendors';

export function FavoritesScreen() {
  const navigation = useNavigation<any>();
  const { favoriteVendorIds, toggleFavorite } = useFavorites();
  const favoriteVendors = vendorTabRecords
    .filter((record) => favoriteVendorIds.includes(record.vendor.id))
    .sort((left, right) => {
      if (left.vendor.liveStatus !== right.vendor.liveStatus) {
        return left.vendor.liveStatus === 'live' ? -1 : 1;
      }

      return left.vendor.distanceKm - right.vendor.distanceKm;
    });

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.hero}>
          <Text style={styles.eyebrow}>Favorites</Text>
          <Text style={styles.title}>Saved vendors</Text>
          <Text style={styles.copy}>
            Save your top vendors here for quick access and future nearby alerts.
          </Text>
        </View>

        {favoriteVendors.length > 0 ? (
          favoriteVendors.map((record) => (
            <Pressable
              key={record.vendor.id}
              style={styles.card}
              onPress={() =>
                navigation.navigate('Vendors', {
                  screen: 'VendorDetail',
                  params: { vendorId: record.vendor.id },
                })
              }
            >
              <View style={styles.cardTop}>
                <View style={styles.identityWrap}>
                  <View style={styles.logoWrap}>
                    <Text style={styles.logoText}>
                      {record.vendor.imageSymbol ?? record.vendor.imageHint}
                    </Text>
                  </View>
                  <View style={styles.textWrap}>
                    <Text style={styles.name}>{record.vendor.businessName}</Text>
                    <Text style={styles.meta}>{record.vendor.category}</Text>
                    <Text style={styles.distance}>{record.vendor.distanceKm} km away</Text>
                  </View>
                </View>
                <Pressable
                  style={styles.favoriteButton}
                  onPress={(event) => {
                    event.stopPropagation();
                    toggleFavorite(record.vendor.id);
                  }}
                >
                  <Text style={styles.favoriteButtonText}>❤️</Text>
                </Pressable>
              </View>

              <View style={styles.infoRow}>
                <View
                  style={[
                    styles.statusBadge,
                    record.vendor.liveStatus === 'live'
                      ? styles.statusBadgeLive
                      : styles.statusBadgeOffline,
                  ]}
                >
                  <Text
                    style={[
                      styles.statusText,
                      record.vendor.liveStatus === 'live'
                        ? styles.statusTextLive
                        : styles.statusTextOffline,
                    ]}
                  >
                    {record.vendor.liveStatus === 'live' ? 'Live now' : 'Offline'}
                  </Text>
                </View>
                <Text style={styles.hours}>{record.vendor.operatingHours}</Text>
              </View>
            </Pressable>
          ))
        ) : (
          <View style={styles.emptyCard}>
            <Text style={styles.emptyTitle}>Nog geen favorieten toegevoegd</Text>
            <Text style={styles.emptyCopy}>
              Sla je favoriete vendors op om ze snel terug te vinden.
            </Text>
            <Pressable
              style={styles.emptyButton}
              onPress={() =>
                navigation.navigate('Vendors', {
                  screen: 'VendorsList',
                })
              }
            >
              <Text style={styles.emptyButtonText}>Bekijk vendors</Text>
            </Pressable>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: palette.ink,
  },
  content: {
    padding: 20,
    gap: 14,
  },
  hero: {
    backgroundColor: palette.panel,
    borderRadius: 28,
    padding: 20,
  },
  eyebrow: {
    color: palette.mint,
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  title: {
    marginTop: 6,
    color: palette.cloud,
    fontSize: 28,
    fontWeight: '800',
  },
  copy: {
    marginTop: 10,
    color: '#B7C4D8',
    lineHeight: 21,
  },
  card: {
    backgroundColor: palette.cloud,
    borderRadius: 24,
    padding: 18,
    gap: 12,
  },
  cardTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
  },
  identityWrap: {
    flex: 1,
    flexDirection: 'row',
    gap: 12,
  },
  logoWrap: {
    width: 56,
    height: 56,
    borderRadius: 18,
    backgroundColor: palette.panel,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoText: {
    color: palette.mint,
    fontSize: 22,
    fontWeight: '900',
  },
  textWrap: {
    flex: 1,
    justifyContent: 'center',
  },
  name: {
    color: palette.ink,
    fontSize: 18,
    fontWeight: '800',
  },
  meta: {
    marginTop: 3,
    color: '#536072',
    fontSize: 13,
    fontWeight: '700',
  },
  distance: {
    marginTop: 4,
    color: '#0F172A',
    fontSize: 13,
    fontWeight: '800',
  },
  favoriteButton: {
    width: 42,
    height: 42,
    borderRadius: 999,
    backgroundColor: '#FDE68A',
    alignItems: 'center',
    justifyContent: 'center',
  },
  favoriteButtonText: {
    color: '#B45309',
    fontSize: 17,
    fontWeight: '800',
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 12,
  },
  statusBadge: {
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 7,
  },
  statusBadgeLive: {
    backgroundColor: palette.success,
  },
  statusBadgeOffline: {
    backgroundColor: palette.danger,
  },
  statusText: {
    fontSize: 11,
    fontWeight: '800',
  },
  statusTextLive: {
    color: palette.successText,
  },
  statusTextOffline: {
    color: palette.dangerText,
  },
  hours: {
    flex: 1,
    textAlign: 'right',
    color: '#64748B',
    fontSize: 12,
    fontWeight: '700',
  },
  emptyCard: {
    backgroundColor: palette.panelAlt,
    borderRadius: 24,
    padding: 20,
    gap: 12,
    alignItems: 'flex-start',
  },
  emptyTitle: {
    color: palette.cloud,
    fontSize: 20,
    fontWeight: '800',
  },
  emptyCopy: {
    color: '#B7C4D8',
    lineHeight: 21,
  },
  emptyButton: {
    marginTop: 4,
    backgroundColor: palette.mint,
    borderRadius: 999,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  emptyButtonText: {
    color: '#0F172A',
    fontSize: 13,
    fontWeight: '800',
  },
});
