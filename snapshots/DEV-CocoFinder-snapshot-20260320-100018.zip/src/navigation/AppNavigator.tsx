import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Text } from 'react-native';
import { palette } from '../config/theme';
import { FavoritesScreen } from '../screens/customer/FavoritesScreen';
import { MapScreen } from '../screens/customer/MapScreen';
import { ProfileScreen } from '../screens/customer/ProfileScreen';
import { MessagesNavigator } from './MessagesNavigator';
import { VendorsNavigator } from './VendorsNavigator';

const Tab = createBottomTabNavigator();

const navTheme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    background: palette.ink,
    card: palette.panel,
    text: palette.cloud,
    primary: palette.mint,
    border: palette.panelAlt,
  },
};

const iconMap = {
  Map: '◎',
  Vendors: '▤',
  Messages: '✉',
  Favorites: '♥',
  Profile: '👤',
} as const;

export function AppNavigator() {
  return (
    <NavigationContainer theme={navTheme}>
      <Tab.Navigator
        initialRouteName="Map"
        screenOptions={({ route }) => ({
          headerShown: false,
          tabBarShowLabel: true,
          tabBarStyle: {
            backgroundColor: palette.panel,
            borderTopColor: palette.panelAlt,
            height: 76,
            paddingBottom: 10,
            paddingTop: 8,
          },
          tabBarLabelStyle: {
            fontSize: 11,
            fontWeight: '700',
          },
          tabBarActiveTintColor: palette.mint,
          tabBarInactiveTintColor: '#92A1B4',
          tabBarIcon: ({ color }) => (
            <Text style={{ color, fontSize: 16 }}>{iconMap[route.name as keyof typeof iconMap]}</Text>
          ),
        })}
      >
        <Tab.Screen name="Map" component={MapScreen} />
        <Tab.Screen
          name="Vendors"
          component={VendorsNavigator}
          listeners={({ navigation }) => ({
            tabPress: () => {
              navigation.navigate('Vendors', {
                screen: 'VendorsList',
              });
            },
          })}
        />
        <Tab.Screen
          name="Messages"
          component={MessagesNavigator}
          listeners={({ navigation }) => ({
            tabPress: () => {
              navigation.navigate('Messages', {
                screen: 'ConversationsList',
              });
            },
          })}
        />
        <Tab.Screen name="Favorites" component={FavoritesScreen} />
        <Tab.Screen name="Profile" component={ProfileScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
