import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Pressable, Text } from 'react-native';
import { MessageConversationScreen } from '../screens/customer/MessageConversationScreen';
import { MessagesScreen } from '../screens/customer/MessagesScreen';
import { palette } from '../config/theme';

export type MessagesStackParamList = {
  ConversationsList: undefined;
  ConversationDetail: { conversationId: string };
};

const Stack = createNativeStackNavigator<MessagesStackParamList>();

export function MessagesNavigator() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: palette.ink,
        },
        headerTintColor: palette.cloud,
        headerTitleStyle: {
          fontWeight: '800',
        },
        contentStyle: {
          backgroundColor: palette.ink,
        },
      }}
    >
      <Stack.Screen
        name="ConversationsList"
        component={MessagesScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="ConversationDetail"
        component={MessageConversationScreen}
        options={({ navigation }) => ({
          title: 'Chat',
          headerLeft: () => (
            <Pressable
              onPress={() => {
                if (navigation.canGoBack()) {
                  navigation.goBack();
                  return;
                }

                navigation.navigate('ConversationsList');
              }}
              style={{
                paddingVertical: 6,
                paddingRight: 12,
              }}
            >
              <Text
                style={{
                  color: palette.cloud,
                  fontSize: 14,
                  fontWeight: '800',
                }}
              >
                Back
              </Text>
            </Pressable>
          ),
        })}
      />
    </Stack.Navigator>
  );
}
