import AsyncStorage from '@react-native-async-storage/async-storage';
import { env } from '../config/env';
import { supabase } from './supabase';

export type VendorProfileSetup = {
  firstName: string;
  lastName: string;
  businessName: string;
  logoSymbol: string;
  category: string;
  country: string;
  phone: string;
  openingHours: string;
  firstProductName: string;
  firstProductPrice: string;
  about: string;
  products?: VendorEditableProduct[];
};

export type VendorEditableProduct = {
  id: string;
  name: string;
  priceLabel: string;
  isAvailable: boolean;
  imageSymbol?: string;
};

export type VendorStoredLocation = {
  latitude: number;
  longitude: number;
  updatedAt: string;
};

export type VendorLiveState = {
  isLive: boolean;
  location: VendorStoredLocation | null;
};

const VENDOR_PROFILE_STORAGE_KEY = 'cocofinder:vendor-profile';
const VENDOR_LIVE_STATE_STORAGE_KEY = 'cocofinder:vendor-live-state';

type VendorProfileRow = {
  user_id: string;
  first_name: string | null;
  last_name: string | null;
  business_name: string | null;
  logo_symbol: string | null;
  category: string | null;
  country: string | null;
  phone: string | null;
  opening_hours: string | null;
  about: string | null;
  is_live: boolean | null;
  live_latitude: number | null;
  live_longitude: number | null;
  live_updated_at: string | null;
};

type VendorProductRow = {
  id: string;
  name: string;
  price_label: string;
  is_available: boolean;
  image_symbol: string | null;
  sort_order: number;
};

function isMissingTableError(message?: string) {
  return Boolean(message && /relation .* does not exist/i.test(message));
}

async function getSupabaseUserId() {
  if (!env.hasSupabase) {
    return null;
  }

  const {
    data: { user },
  } = await supabase.auth.getUser();

  return user?.id ?? null;
}

function normalizeVendorProfile(parsed: VendorProfileSetup): VendorProfileSetup | null {
  if (
    typeof parsed.firstName !== 'string' ||
    typeof parsed.lastName !== 'string' ||
    typeof parsed.businessName !== 'string' ||
    typeof parsed.logoSymbol !== 'string' ||
    typeof parsed.category !== 'string' ||
    (typeof parsed.country !== 'string' && typeof parsed.country !== 'undefined') ||
    typeof parsed.phone !== 'string' ||
    typeof parsed.openingHours !== 'string' ||
    typeof parsed.firstProductName !== 'string' ||
    typeof parsed.firstProductPrice !== 'string' ||
    typeof parsed.about !== 'string'
  ) {
    return null;
  }

  const normalizedProducts = Array.isArray(parsed.products)
    ? parsed.products.filter(
        (product): product is VendorEditableProduct =>
          typeof product?.id === 'string' &&
          typeof product?.name === 'string' &&
          typeof product?.priceLabel === 'string' &&
          typeof product?.isAvailable === 'boolean' &&
          (typeof product?.imageSymbol === 'string' || typeof product?.imageSymbol === 'undefined')
      )
    : [];

  const seededProducts =
    normalizedProducts.length > 0
      ? normalizedProducts
      : [
          {
            id: 'vendor-product-primary',
            name: parsed.firstProductName,
            priceLabel: parsed.firstProductPrice,
            isAvailable: true,
            imageSymbol: parsed.logoSymbol,
          },
        ];

  return {
    ...parsed,
    firstName: parsed.firstName || 'Michaello',
    lastName: parsed.lastName || 'Vendor',
    country: parsed.country || 'Netherlands',
    products: seededProducts,
  };
}

function mapSupabaseProfileToLocal(
  profileRow: VendorProfileRow,
  productRows: VendorProductRow[]
): VendorProfileSetup {
  const normalizedProducts =
    productRows.length > 0
      ? productRows
          .sort((a, b) => a.sort_order - b.sort_order)
          .map((product) => ({
            id: product.id,
            name: product.name,
            priceLabel: product.price_label,
            isAvailable: product.is_available,
            imageSymbol: product.image_symbol ?? undefined,
          }))
      : [
          {
            id: 'vendor-product-primary',
            name: '',
            priceLabel: '',
            isAvailable: true,
            imageSymbol: profileRow.logo_symbol ?? '🛺',
          },
        ];

  return normalizeVendorProfile({
    firstName: profileRow.first_name ?? '',
    lastName: profileRow.last_name ?? '',
    businessName: profileRow.business_name ?? '',
    logoSymbol: profileRow.logo_symbol ?? '',
    category: profileRow.category ?? '',
    country: profileRow.country ?? 'Netherlands',
    phone: profileRow.phone ?? '',
    openingHours: profileRow.opening_hours ?? '',
    firstProductName: normalizedProducts[0]?.name ?? '',
    firstProductPrice: normalizedProducts[0]?.priceLabel ?? '',
    about: profileRow.about ?? '',
    products: normalizedProducts,
  }) ?? {
    firstName: 'Michaello',
    lastName: 'Vendor',
    businessName: '',
    logoSymbol: '🛺',
    category: '',
    country: 'Netherlands',
    phone: '',
    openingHours: '',
    firstProductName: '',
    firstProductPrice: '',
    about: '',
    products: normalizedProducts,
  };
}

async function getSupabaseVendorProfile(): Promise<VendorProfileSetup | null> {
  const userId = await getSupabaseUserId();

  if (!userId) {
    return null;
  }

  const [{ data: profileRow, error: profileError }, { data: productRows, error: productsError }] =
    await Promise.all([
      supabase.from('vendor_profiles').select('*').eq('user_id', userId).maybeSingle(),
      supabase
        .from('vendor_products')
        .select('id,name,price_label,is_available,image_symbol,sort_order')
        .eq('user_id', userId)
        .order('sort_order', { ascending: true }),
    ]);

  if (profileError && !isMissingTableError(profileError.message)) {
    throw profileError;
  }

  if (productsError && !isMissingTableError(productsError.message)) {
    throw productsError;
  }

  if (!profileRow) {
    return null;
  }

  return mapSupabaseProfileToLocal(
    profileRow as VendorProfileRow,
    (productRows ?? []) as VendorProductRow[]
  );
}

async function saveSupabaseVendorProfile(profile: VendorProfileSetup) {
  const userId = await getSupabaseUserId();

  if (!userId) {
    return;
  }

  const { error: profileError } = await supabase.from('vendor_profiles').upsert(
    {
      user_id: userId,
      first_name: profile.firstName,
      last_name: profile.lastName,
      business_name: profile.businessName,
      logo_symbol: profile.logoSymbol,
      category: profile.category,
      country: profile.country,
      phone: profile.phone,
      opening_hours: profile.openingHours,
      about: profile.about,
      updated_at: new Date().toISOString(),
    },
    {
      onConflict: 'user_id',
    }
  );

  if (profileError && !isMissingTableError(profileError.message)) {
    throw profileError;
  }

  const { error: deleteError } = await supabase.from('vendor_products').delete().eq('user_id', userId);

  if (deleteError && !isMissingTableError(deleteError.message)) {
    throw deleteError;
  }

  const products = (profile.products ?? []).map((product, index) => ({
    id: product.id,
    user_id: userId,
    name: product.name,
    price_label: product.priceLabel,
    is_available: product.isAvailable,
    image_symbol: product.imageSymbol ?? null,
    sort_order: index,
    updated_at: new Date().toISOString(),
  }));

  if (products.length === 0) {
    return;
  }

  const { error: productsError } = await supabase.from('vendor_products').insert(products);

  if (productsError && !isMissingTableError(productsError.message)) {
    throw productsError;
  }
}

async function clearSupabaseVendorProfile() {
  const userId = await getSupabaseUserId();

  if (!userId) {
    return;
  }

  const [productsResult, profileResult] = await Promise.all([
    supabase.from('vendor_products').delete().eq('user_id', userId),
    supabase.from('vendor_profiles').delete().eq('user_id', userId),
  ]);

  if (productsResult.error && !isMissingTableError(productsResult.error.message)) {
    throw productsResult.error;
  }

  if (profileResult.error && !isMissingTableError(profileResult.error.message)) {
    throw profileResult.error;
  }
}

async function getSupabaseVendorLiveState(): Promise<VendorLiveState | null> {
  const userId = await getSupabaseUserId();

  if (!userId) {
    return null;
  }

  const { data, error } = await supabase
    .from('vendor_profiles')
    .select('is_live,live_latitude,live_longitude,live_updated_at')
    .eq('user_id', userId)
    .maybeSingle();

  if (error && !isMissingTableError(error.message)) {
    throw error;
  }

  if (!data) {
    return null;
  }

  return {
    isLive: Boolean(data.is_live),
    location:
      typeof data.live_latitude === 'number' &&
      typeof data.live_longitude === 'number' &&
      typeof data.live_updated_at === 'string'
        ? {
            latitude: data.live_latitude,
            longitude: data.live_longitude,
            updatedAt: data.live_updated_at,
          }
        : null,
  };
}

async function saveSupabaseVendorLiveState(liveState: VendorLiveState) {
  const userId = await getSupabaseUserId();

  if (!userId) {
    return;
  }

  const { error } = await supabase.from('vendor_profiles').upsert(
    {
      user_id: userId,
      is_live: liveState.isLive,
      live_latitude: liveState.location?.latitude ?? null,
      live_longitude: liveState.location?.longitude ?? null,
      live_updated_at: liveState.location?.updatedAt ?? null,
      updated_at: new Date().toISOString(),
    },
    {
      onConflict: 'user_id',
    }
  );

  if (error && !isMissingTableError(error.message)) {
    throw error;
  }
}

export async function getVendorProfile(): Promise<VendorProfileSetup | null> {
  try {
    const supabaseProfile = await getSupabaseVendorProfile();

    if (supabaseProfile) {
      await AsyncStorage.setItem(VENDOR_PROFILE_STORAGE_KEY, JSON.stringify(supabaseProfile));
      return supabaseProfile;
    }
  } catch {}

  const storedValue = await AsyncStorage.getItem(VENDOR_PROFILE_STORAGE_KEY);

  if (!storedValue) {
    return null;
  }

  try {
    const parsed = JSON.parse(storedValue) as VendorProfileSetup;
    const normalizedProfile = normalizeVendorProfile(parsed);

    if (normalizedProfile) {
      return normalizedProfile;
    }
  } catch {}

  return null;
}

export async function hasVendorProfile() {
  const profile = await getVendorProfile();

  return Boolean(
    profile &&
      profile.firstName.trim() &&
      profile.lastName.trim() &&
      profile.businessName.trim() &&
      profile.logoSymbol.trim() &&
      profile.category.trim() &&
      profile.country.trim() &&
      profile.phone.trim() &&
      profile.openingHours.trim() &&
      profile.firstProductName.trim() &&
      profile.firstProductPrice.trim() &&
      profile.about.trim()
  );
}

export async function saveVendorProfile(profile: VendorProfileSetup) {
  const normalizedProfile = normalizeVendorProfile(profile);

  if (!normalizedProfile) {
    return;
  }

  await AsyncStorage.setItem(VENDOR_PROFILE_STORAGE_KEY, JSON.stringify(normalizedProfile));
  try {
    await saveSupabaseVendorProfile(normalizedProfile);
  } catch {}
}

export async function clearVendorProfile() {
  await AsyncStorage.removeItem(VENDOR_PROFILE_STORAGE_KEY);
  try {
    await clearSupabaseVendorProfile();
  } catch {}
}

export async function getVendorLiveState(): Promise<VendorLiveState> {
  try {
    const supabaseLiveState = await getSupabaseVendorLiveState();

    if (supabaseLiveState) {
      await AsyncStorage.setItem(VENDOR_LIVE_STATE_STORAGE_KEY, JSON.stringify(supabaseLiveState));
      return supabaseLiveState;
    }
  } catch {}

  const storedValue = await AsyncStorage.getItem(VENDOR_LIVE_STATE_STORAGE_KEY);

  if (!storedValue) {
    return {
      isLive: false,
      location: null,
    };
  }

  try {
    const parsed = JSON.parse(storedValue) as VendorLiveState;
    const isValidLocation =
      parsed.location === null ||
      (typeof parsed.location?.latitude === 'number' &&
        typeof parsed.location?.longitude === 'number' &&
        typeof parsed.location?.updatedAt === 'string');

    if (typeof parsed.isLive === 'boolean' && isValidLocation) {
      return parsed;
    }
  } catch {}

  return {
    isLive: false,
    location: null,
  };
}

export async function saveVendorLiveState(liveState: VendorLiveState) {
  await AsyncStorage.setItem(VENDOR_LIVE_STATE_STORAGE_KEY, JSON.stringify(liveState));
  try {
    await saveSupabaseVendorLiveState(liveState);
  } catch {}
}

export async function clearVendorLiveState() {
  await AsyncStorage.removeItem(VENDOR_LIVE_STATE_STORAGE_KEY);
}
