import { RouteProp, useRoute } from '@react-navigation/native';
import { useEffect, useState } from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { palette } from '../../config/theme';
import { useMessages } from '../../context/MessagesContext';
import { MessagesStackParamList } from '../../navigation/MessagesNavigator';

type ConversationRoute = RouteProp<MessagesStackParamList, 'ConversationDetail'>;

export function MessageConversationScreen() {
  const route = useRoute<ConversationRoute>();
  const [draft, setDraft] = useState('');
  const {
    getConversationById,
    getMessagesForConversation,
    markConversationRead,
    sendMessage,
  } = useMessages();
  const summary = getConversationById(route.params.conversationId);
  const messages = getMessagesForConversation(route.params.conversationId);

  useEffect(() => {
    markConversationRead(route.params.conversationId);
  }, [markConversationRead, route.params.conversationId]);

  function handleSend() {
    const trimmedDraft = draft.trim();

    if (!trimmedDraft) {
      return;
    }

    sendMessage(route.params.conversationId, trimmedDraft);
    setDraft('');
  }

  if (!summary) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.missingWrap}>
          <Text style={styles.missingTitle}>Conversation not found</Text>
          <Text style={styles.missingCopy}>
            This chat could not be loaded right now.
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea} edges={['left', 'right']}>
      <KeyboardAvoidingView
        style={styles.keyboardAvoider}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 92 : 24}
      >
        <View style={styles.container}>
          <View style={styles.headerCard}>
            <View style={styles.symbolWrap}>
              <Text style={styles.symbolText}>{summary.vendorSymbol ?? summary.vendorName[0]}</Text>
            </View>
            <View style={styles.headerText}>
              <Text style={styles.vendorName}>{summary.vendorName}</Text>
              <Text style={styles.vendorMeta}>
                {summary.vendorCategory} · {summary.isVendorLive ? 'Live now' : 'Offline'}
              </Text>
            </View>
          </View>

          <ScrollView
            style={styles.messagesScroll}
            contentContainerStyle={styles.messagesContent}
            keyboardShouldPersistTaps="handled"
          >
            {messages.map((message) => {
              const isCustomer = message.senderRole === 'customer';

              return (
                <View
                  style={[
                    styles.messageRow,
                    isCustomer ? styles.messageRowCustomer : styles.messageRowVendor,
                  ]}
                  key={message.id}
                >
                  <View
                    style={[
                      styles.messageBubble,
                      isCustomer ? styles.messageBubbleCustomer : styles.messageBubbleVendor,
                    ]}
                  >
                    <Text
                      style={[
                        styles.messageBody,
                        isCustomer ? styles.messageBodyCustomer : styles.messageBodyVendor,
                      ]}
                    >
                      {message.body}
                    </Text>
                    <Text
                      style={[
                        styles.messageTime,
                        isCustomer ? styles.messageTimeCustomer : styles.messageTimeVendor,
                      ]}
                    >
                      {message.sentAt}
                    </Text>
                  </View>
                </View>
              );
            })}
          </ScrollView>

          <View style={styles.composer}>
            <TextInput
              value={draft}
              onChangeText={setDraft}
              placeholder={`Message ${summary.vendorName}`}
              placeholderTextColor="#7C8BA1"
              style={styles.input}
              multiline
            />
            <Pressable style={styles.sendButton} onPress={handleSend}>
              <Text style={styles.sendButtonText}>Send</Text>
            </Pressable>
          </View>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: palette.ink,
  },
  keyboardAvoider: {
    flex: 1,
  },
  container: {
    flex: 1,
    padding: 20,
    gap: 14,
  },
  missingWrap: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  missingTitle: {
    color: palette.cloud,
    fontSize: 24,
    fontWeight: '800',
  },
  missingCopy: {
    marginTop: 8,
    color: '#B7C4D8',
    fontSize: 14,
    textAlign: 'center',
  },
  headerCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    backgroundColor: palette.panel,
    borderRadius: 24,
    padding: 16,
  },
  symbolWrap: {
    width: 52,
    height: 52,
    borderRadius: 16,
    backgroundColor: palette.cloud,
    alignItems: 'center',
    justifyContent: 'center',
  },
  symbolText: {
    fontSize: 22,
    fontWeight: '800',
  },
  headerText: {
    flex: 1,
  },
  vendorName: {
    color: palette.cloud,
    fontSize: 18,
    fontWeight: '800',
  },
  vendorMeta: {
    marginTop: 4,
    color: '#B7C4D8',
    fontSize: 13,
    fontWeight: '700',
  },
  messagesScroll: {
    flex: 1,
  },
  messagesContent: {
    flexGrow: 1,
    paddingBottom: 10,
    gap: 10,
  },
  messageRow: {
    flexDirection: 'row',
  },
  messageRowCustomer: {
    justifyContent: 'flex-end',
  },
  messageRowVendor: {
    justifyContent: 'flex-start',
  },
  messageBubble: {
    maxWidth: '82%',
    borderRadius: 22,
    paddingHorizontal: 14,
    paddingVertical: 12,
    gap: 6,
  },
  messageBubbleCustomer: {
    backgroundColor: palette.mint,
    borderBottomRightRadius: 8,
  },
  messageBubbleVendor: {
    backgroundColor: palette.panelAlt,
    borderBottomLeftRadius: 8,
  },
  messageBody: {
    fontSize: 14,
    lineHeight: 20,
  },
  messageBodyCustomer: {
    color: '#06221A',
  },
  messageBodyVendor: {
    color: palette.cloud,
  },
  messageTime: {
    fontSize: 11,
    fontWeight: '700',
  },
  messageTimeCustomer: {
    color: '#14532D',
  },
  messageTimeVendor: {
    color: '#9FB0C8',
  },
  composer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 10,
    backgroundColor: palette.panel,
    borderRadius: 24,
    padding: 12,
    marginBottom: 12,
  },
  input: {
    flex: 1,
    minHeight: 44,
    maxHeight: 96,
    color: palette.cloud,
    fontSize: 14,
    paddingHorizontal: 8,
    paddingTop: 10,
  },
  sendButton: {
    backgroundColor: palette.mint,
    borderRadius: 999,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  sendButtonText: {
    color: '#0F172A',
    fontSize: 13,
    fontWeight: '800',
  },
});
