import { useCallback, useState } from 'react';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { palette } from '../../config/theme';
import { useFavorites } from '../../context/FavoritesContext';
import { useCurrentLocation } from '../../hooks/useCurrentLocation';
import { useDebouncedValue } from '../../hooks/useDebouncedValue';
import { useVendorData } from '../../hooks/useVendorData';
import { searchVendorRecords } from '../../lib/search';
import { VendorsStackParamList } from '../../navigation/VendorsNavigator';

export function VendorsScreen() {
  const navigation =
    useNavigation<NativeStackNavigationProp<VendorsStackParamList, 'VendorsList'>>();
  const { isFavorite, toggleFavorite } = useFavorites();
  const locationState = useCurrentLocation();
  const { vendorTabRecords, reloadVendorData } = useVendorData(locationState.coords);
  const [searchText, setSearchText] = useState('');
  const debouncedSearchText = useDebouncedValue(searchText, 300);
  const nearbyVendors = vendorTabRecords
    .filter((record) => record.vendor.liveStatus === 'live')
    .sort((left, right) => left.vendor.distanceKm - right.vendor.distanceKm);
  const searchResults = searchVendorRecords(nearbyVendors, debouncedSearchText);
  const filteredVendors = debouncedSearchText.trim() ? searchResults : [];

  useFocusEffect(
    useCallback(() => {
      void reloadVendorData();
    }, [reloadVendorData])
  );

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.hero}>
          <Text style={styles.eyebrow}>Nearby Vendors</Text>
          <Text style={styles.title}>Vendors near you</Text>
          <Text style={styles.copy}>
            Tap any nearby vendor to open the detail card, then use back to return to this list.
          </Text>
        </View>

        <View style={styles.searchBar}>
          <TextInput
            value={searchText}
            onChangeText={setSearchText}
            placeholder="Search vendors or products"
            placeholderTextColor="#7C8BA1"
            style={styles.searchInput}
          />
        </View>

        <View style={styles.listWrap}>
          {(debouncedSearchText.trim() ? filteredVendors : nearbyVendors).length > 0 ? (
            (debouncedSearchText.trim() ? filteredVendors : nearbyVendors).map((item) => {
              const record = 'record' in item ? item.record : item;
              const matchedProductName =
                'matchedProductName' in item ? item.matchedProductName : undefined;
            const vendorIsFavorite = isFavorite(record.vendor.id);

            return (
              <Pressable
                key={record.vendor.id}
                style={styles.row}
                onPress={() =>
                  navigation.navigate('VendorDetail', { vendorId: record.vendor.id })
                }
              >
                <View style={styles.logoWrap}>
                  <Text style={styles.logoText}>
                    {record.vendor.imageSymbol ?? record.vendor.imageHint}
                  </Text>
                </View>

                <View style={styles.main}>
                  <View style={styles.topLine}>
                    <Text style={styles.name}>{record.vendor.businessName}</Text>
                    {record.vendor.liveStatus === 'live' ? (
                      <View style={styles.liveBadge}>
                        <Text style={styles.liveBadgeText}>LIVE</Text>
                      </View>
                    ) : null}
                  </View>

                  <Text style={styles.meta}>
                    {record.vendor.category} · {record.vendor.distanceKm} km away
                  </Text>
                  {matchedProductName ? (
                    <Text style={styles.matchText}>Product: {matchedProductName}</Text>
                  ) : null}
                  <Text style={styles.hours}>{record.vendor.operatingHours}</Text>

                  <View style={styles.bottomLine}>
                    <Text style={styles.priceHint}>{record.vendor.priceHint}</Text>
                    <Text style={styles.productsCount}>
                      {record.vendor.liveStatus === 'live' ? 'Live now' : 'Offline'}
                    </Text>
                  </View>
                </View>

                <Pressable
                  style={[
                    styles.favoriteButton,
                    vendorIsFavorite && styles.favoriteButtonActive,
                  ]}
                  onPress={(event) => {
                    event.stopPropagation();
                    toggleFavorite(record.vendor.id);
                  }}
                >
                  <Text
                    style={[
                      styles.favoriteButtonText,
                      vendorIsFavorite && styles.favoriteButtonTextActive,
                    ]}
                  >
                    {vendorIsFavorite ? '♥' : '♡'}
                  </Text>
                </Pressable>
              </Pressable>
            );
            })
          ) : (
            <View style={styles.emptyState}>
              <Text style={styles.emptyStateTitle}>Geen resultaten gevonden</Text>
              <Text style={styles.emptyStateCopy}>Probeer een andere zoekterm</Text>
            </View>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: palette.ink,
  },
  content: {
    padding: 20,
    gap: 16,
  },
  hero: {
    backgroundColor: palette.panel,
    borderRadius: 24,
    padding: 18,
  },
  eyebrow: {
    color: palette.mint,
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  title: {
    marginTop: 6,
    color: palette.cloud,
    fontSize: 26,
    fontWeight: '800',
  },
  copy: {
    marginTop: 10,
    color: '#B7C4D8',
    lineHeight: 21,
  },
  searchBar: {
    backgroundColor: palette.panelAlt,
    borderRadius: 999,
    paddingHorizontal: 18,
    paddingVertical: 14,
  },
  searchInput: {
    color: palette.cloud,
    fontSize: 15,
    fontWeight: '500',
  },
  listWrap: {
    gap: 10,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: palette.cloud,
    borderRadius: 22,
    paddingHorizontal: 14,
    paddingVertical: 14,
  },
  logoWrap: {
    width: 52,
    height: 52,
    borderRadius: 16,
    backgroundColor: palette.panel,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoText: {
    color: palette.mint,
    fontSize: 18,
    fontWeight: '900',
  },
  main: {
    flex: 1,
    gap: 3,
  },
  topLine: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  name: {
    flexShrink: 1,
    color: palette.ink,
    fontSize: 17,
    fontWeight: '800',
  },
  liveBadge: {
    borderRadius: 999,
    backgroundColor: '#DCFCE7',
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  liveBadgeText: {
    color: '#166534',
    fontSize: 10,
    fontWeight: '800',
  },
  meta: {
    color: '#475569',
    fontSize: 12,
    fontWeight: '700',
  },
  matchText: {
    color: '#0F172A',
    fontSize: 12,
    fontWeight: '700',
  },
  hours: {
    color: '#64748B',
    fontSize: 12,
  },
  bottomLine: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 3,
  },
  priceHint: {
    color: '#0F172A',
    fontSize: 12,
    fontWeight: '700',
  },
  productsCount: {
    color: '#64748B',
    fontSize: 12,
    fontWeight: '700',
  },
  favoriteButton: {
    width: 38,
    height: 38,
    borderRadius: 999,
    backgroundColor: '#E2E8F0',
    alignItems: 'center',
    justifyContent: 'center',
  },
  favoriteButtonActive: {
    backgroundColor: '#FDE68A',
  },
  favoriteButtonText: {
    color: '#475569',
    fontSize: 16,
    fontWeight: '800',
  },
  favoriteButtonTextActive: {
    color: '#92400E',
  },
  emptyState: {
    backgroundColor: palette.panelAlt,
    borderRadius: 24,
    padding: 20,
    gap: 8,
  },
  emptyStateTitle: {
    color: palette.cloud,
    fontSize: 18,
    fontWeight: '800',
  },
  emptyStateCopy: {
    color: '#B7C4D8',
    lineHeight: 21,
  },
});
