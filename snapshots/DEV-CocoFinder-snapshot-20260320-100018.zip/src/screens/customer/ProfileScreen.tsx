import { useCallback, useEffect, useState } from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Alert, Pressable, ScrollView, StyleSheet, Switch, Text, TextInput, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import * as Location from 'expo-location';
import { useAuth } from '../../context/AuthContext';
import { palette } from '../../config/theme';
import { formatPriceForCountry } from '../../lib/currency';
import { resetOnboarding } from '../../lib/onboarding';
import {
  clearVendorLiveState,
  clearVendorProfile,
  type VendorEditableProduct,
  getVendorLiveState,
  getVendorProfile,
  saveVendorLiveState,
  saveVendorProfile,
  type VendorLiveState,
  type VendorProfileSetup,
} from '../../lib/vendorProfile';

const settings = [
  'Account details',
  'Location permissions',
  'Notification preferences',
  'Payment methods',
  'Privacy and GDPR controls',
] as const;

function TrashOutlineIcon() {
  return (
    <View style={styles.trashIconWrap}>
      <View style={styles.trashIconLid} />
      <View style={styles.trashIconHandle} />
      <View style={styles.trashIconBody}>
        <View style={styles.trashIconLine} />
        <View style={styles.trashIconLine} />
      </View>
    </View>
  );
}

function VendorProfileEditor({
  initialProfile,
  vendorLiveState,
}: {
  initialProfile: VendorProfileSetup | null;
  vendorLiveState: VendorLiveState;
}) {
  const [isEditing, setIsEditing] = useState(false);
  const [profile, setProfile] = useState<VendorProfileSetup | null>(initialProfile);
  const [draft, setDraft] = useState<VendorProfileSetup | null>(initialProfile);

  useEffect(() => {
    setProfile(initialProfile);
    setDraft(initialProfile);
  }, [initialProfile]);

  if (!profile || !draft) {
    return (
      <View style={styles.vendorCard}>
        <Text style={styles.vendorEyebrow}>Vendor Profile</Text>
        <Text style={styles.vendorTitle}>Profile not available</Text>
        <Text style={styles.vendorCopy}>
          Complete vendor setup first to manage your business details here.
        </Text>
      </View>
    );
  }

  const missingFields = [
    !draft.firstName.trim() ? 'First name' : null,
    !draft.lastName.trim() ? 'Last name' : null,
    !draft.businessName.trim() ? 'Business name' : null,
    !draft.logoSymbol.trim() ? 'Logo symbol' : null,
    !draft.category.trim() ? 'Category' : null,
    !draft.country.trim() ? 'Country' : null,
    !draft.phone.trim() ? 'Phone' : null,
    !draft.openingHours.trim() ? 'Opening hours' : null,
    !(draft.products ?? []).length ? 'At least one product' : null,
    (draft.products ?? []).some((product) => !product.name.trim()) ? 'Product name' : null,
    (draft.products ?? []).some((product) => !product.priceLabel.trim()) ? 'Product price' : null,
    !draft.about.trim() ? 'About' : null,
  ].filter(Boolean) as string[];

  async function handleSave() {
    if (missingFields.length > 0) {
      Alert.alert('Complete vendor profile', `Please fill in: ${missingFields.join(', ')}`);
      return;
    }

    const profileToSave = draft;

    if (!profileToSave) {
      return;
    }

    const normalizedProducts = (profileToSave.products ?? []).map((product) => ({
      ...product,
      priceLabel: formatPriceForCountry(profileToSave.country, product.priceLabel),
    }));
    const primaryProduct = normalizedProducts[0] ?? {
      id: 'vendor-product-primary',
      name: '',
      priceLabel: '',
      isAvailable: true,
      imageSymbol: profileToSave.logoSymbol,
    };
    const normalizedProfileToSave: VendorProfileSetup = {
      ...profileToSave,
      firstProductName: primaryProduct.name,
      firstProductPrice: primaryProduct.priceLabel,
      products: normalizedProducts,
    };

    await saveVendorProfile(normalizedProfileToSave);
    setProfile(normalizedProfileToSave);
    setDraft(normalizedProfileToSave);
    setIsEditing(false);
    Alert.alert('Profile saved', 'Your vendor profile has been updated.');
  }

  function updateField<K extends keyof VendorProfileSetup>(key: K, value: VendorProfileSetup[K]) {
    setDraft((current) => (current ? { ...current, [key]: value } : current));
  }

  function updateProducts(nextProducts: VendorEditableProduct[]) {
    setDraft((current) => {
      if (!current) {
        return current;
      }

      const primaryProduct = nextProducts[0] ?? {
        id: 'vendor-product-primary',
        name: '',
        priceLabel: '',
      };

      return {
        ...current,
        products: nextProducts,
        firstProductName: primaryProduct.name,
        firstProductPrice: primaryProduct.priceLabel,
      };
    });
  }

  function addProduct() {
    if (!draft) {
      return;
    }

    const nextIndex = (draft.products?.length ?? 0) + 1;
    const nextProducts = [
      ...(draft.products ?? []),
      {
        id: `vendor-product-${nextIndex}`,
        name: '',
        priceLabel: '',
        isAvailable: true,
        imageSymbol: '🍽️',
      },
    ];
    updateProducts(nextProducts);
  }

  function updateProduct(productId: string, field: keyof VendorEditableProduct, value: string) {
    if (!draft) {
      return;
    }

    const nextProducts = (draft.products ?? []).map((product) =>
      product.id === productId ? { ...product, [field]: value } : product
    );
    updateProducts(nextProducts);
  }

  function toggleProductAvailability(productId: string) {
    if (!draft) {
      return;
    }

    const nextProducts = (draft.products ?? []).map((product) =>
      product.id === productId ? { ...product, isAvailable: !product.isAvailable } : product
    );
    updateProducts(nextProducts);
  }

  function moveProduct(productId: string, direction: 'up' | 'down') {
    if (!draft) {
      return;
    }

    const nextProducts = [...(draft.products ?? [])];
    const currentIndex = nextProducts.findIndex((product) => product.id === productId);

    if (currentIndex < 0) {
      return;
    }

    const targetIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1;

    if (targetIndex < 0 || targetIndex >= nextProducts.length) {
      return;
    }

    const temp = nextProducts[currentIndex];
    nextProducts[currentIndex] = nextProducts[targetIndex];
    nextProducts[targetIndex] = temp;
    updateProducts(nextProducts);
  }

  function removeProduct(productId: string) {
    if (!draft) {
      return;
    }

    const nextProducts = (draft.products ?? []).filter((product) => product.id !== productId);
    updateProducts(nextProducts);
  }

  const liveBusinessStatus = vendorLiveState.isLive ? 'Open now' : 'Closed';

  return (
    <View style={styles.vendorStack}>
      <View style={styles.sectionCard}>
        <Text style={styles.sectionEyebrow}>Personal details</Text>
        <Text style={styles.sectionTitle}>About you</Text>
        <Text style={styles.vendorCopy}>
          Keep your contact details ready so your vendor identity always feels personal and clear.
        </Text>
        <View style={styles.vendorBlock}>
          <Text style={styles.blockLabel}>Contact person</Text>
          {isEditing ? (
            <View style={styles.formRow}>
              <TextInput
                value={draft.firstName}
                onChangeText={(value) => updateField('firstName', value)}
                placeholder="First name"
                placeholderTextColor="#8C9AAF"
                style={[styles.profileInput, styles.formRowMain]}
              />
              <TextInput
                value={draft.lastName}
                onChangeText={(value) => updateField('lastName', value)}
                placeholder="Last name"
                placeholderTextColor="#8C9AAF"
                style={[styles.profileInput, styles.formRowMain]}
              />
            </View>
          ) : (
            <Text style={styles.blockText}>
              {profile.firstName} {profile.lastName}
            </Text>
          )}
        </View>
      </View>

      <View style={styles.sectionCard}>
        <Text style={styles.sectionEyebrow}>Your business</Text>
        <Text style={styles.sectionTitle}>Business profile</Text>

        <View style={styles.vendorHeaderRow}>
          <View style={styles.vendorHeaderCopy}>
            <Text style={styles.vendorCopy}>
              Keep your business details accurate so customers always see the right information.
            </Text>
          </View>

          <Pressable
            style={[styles.editButton, isEditing && styles.editButtonActive]}
            onPress={() => {
              if (isEditing) {
                setDraft(profile);
                setIsEditing(false);
                return;
              }

              setDraft(profile);
              setIsEditing(true);
            }}
          >
            <Text style={[styles.editButtonText, isEditing && styles.editButtonTextActive]}>
              {isEditing ? 'Cancel' : 'Edit'}
            </Text>
          </Pressable>
        </View>

        <View style={styles.vendorBlock}>
          <Text style={styles.blockLabel}>Business details</Text>
          <View style={styles.vendorIdentityRow}>
            <View style={styles.vendorLogoBox}>
              <Text style={styles.vendorLogoText}>
                {isEditing ? draft.logoSymbol || '🛺' : profile.logoSymbol}
              </Text>
            </View>
            <View style={styles.vendorIdentityCopy}>
              <Text style={styles.blockTitle}>{profile.businessName}</Text>
              <Text style={styles.blockText}>{profile.phone}</Text>
            </View>
          </View>

          {isEditing ? (
            <View style={styles.formStack}>
              <TextInput
                value={draft.businessName}
                onChangeText={(value) => updateField('businessName', value)}
                placeholder="Business name"
                placeholderTextColor="#8C9AAF"
                style={styles.profileInput}
              />
              <TextInput
                value={draft.logoSymbol}
                onChangeText={(value) => updateField('logoSymbol', value)}
                placeholder="Logo symbol"
                placeholderTextColor="#8C9AAF"
                style={styles.profileInput}
              />
              <TextInput
                value={draft.phone}
                onChangeText={(value) => updateField('phone', value)}
                placeholder="Phone"
                placeholderTextColor="#8C9AAF"
                style={styles.profileInput}
              />
              <TextInput
                value={draft.country}
                onChangeText={(value) => updateField('country', value)}
                placeholder="Country"
                placeholderTextColor="#8C9AAF"
                style={styles.profileInput}
              />
            </View>
          ) : null}
        </View>

        <View style={styles.vendorBlock}>
          <Text style={styles.blockLabel}>About</Text>
          {isEditing ? (
            <TextInput
              value={draft.about}
              onChangeText={(value) => updateField('about', value)}
              placeholder="About your business"
              placeholderTextColor="#8C9AAF"
              style={[styles.profileInput, styles.profileTextArea]}
              multiline
              textAlignVertical="top"
            />
          ) : (
            <Text style={styles.blockText}>{profile.about}</Text>
          )}
        </View>

        <View style={styles.vendorBlock}>
          <Text style={styles.blockLabel}>Category</Text>
          {isEditing ? (
            <TextInput
              value={draft.category}
              onChangeText={(value) => updateField('category', value)}
              placeholder="Category"
              placeholderTextColor="#8C9AAF"
              style={styles.profileInput}
            />
          ) : (
            <Text style={styles.blockText}>
              {profile.category}{'\n'}
              Country: {profile.country}
            </Text>
          )}
        </View>

        {isEditing ? (
          <Pressable style={styles.saveButton} onPress={() => void handleSave()}>
            <Text style={styles.saveButtonText}>Save changes</Text>
          </Pressable>
        ) : null}
      </View>

      <View style={styles.sectionCard}>
        <Text style={styles.sectionEyebrow}>Products</Text>
        <Text style={styles.sectionTitle}>Products & pricing</Text>
        <Text style={styles.vendorCopy}>
          Manage the products customers see first, including pricing, icons and availability.
        </Text>
        <View style={styles.settingsListDark}>
          {isEditing ? (
            <>
              {(draft.products ?? []).map((product, index) => (
                <View key={product.id} style={styles.productEditorCard}>
                  <View style={styles.productEditorHeader}>
                    <View style={styles.productEditorTitleRow}>
                      <View style={styles.productIconBubble}>
                        <Text style={styles.productIconBubbleText}>
                          {product.imageSymbol || '🍽️'}
                        </Text>
                      </View>
                      <View>
                        <Text style={styles.settingTextDark}>Product {index + 1}</Text>
                        <Text style={styles.settingMetaDark}>
                          {product.isAvailable ? 'Available now' : 'Hidden from customers'}
                        </Text>
                      </View>
                    </View>
                    <View style={styles.productEditorActions}>
                      <Pressable onPress={() => moveProduct(product.id, 'up')}>
                        <Text style={styles.productSortText}>↑</Text>
                      </Pressable>
                      <Pressable onPress={() => moveProduct(product.id, 'down')}>
                        <Text style={styles.productSortText}>↓</Text>
                      </Pressable>
                      {(draft.products?.length ?? 0) > 1 ? (
                        <Pressable onPress={() => removeProduct(product.id)}>
                          <Text style={styles.removeProductText}>Remove</Text>
                        </Pressable>
                      ) : null}
                    </View>
                  </View>
                  <View style={styles.formStack}>
                    <TextInput
                      value={product.imageSymbol ?? ''}
                      onChangeText={(value) => updateProduct(product.id, 'imageSymbol', value)}
                      placeholder="Product icon"
                      placeholderTextColor="#8C9AAF"
                      style={styles.profileInput}
                    />
                    <TextInput
                      value={product.name}
                      onChangeText={(value) => updateProduct(product.id, 'name', value)}
                      placeholder="Product name"
                      placeholderTextColor="#8C9AAF"
                      style={styles.profileInput}
                    />
                    <TextInput
                      value={product.priceLabel}
                      onChangeText={(value) => updateProduct(product.id, 'priceLabel', value)}
                      placeholder="Price"
                      placeholderTextColor="#8C9AAF"
                      style={styles.profileInput}
                    />
                    <Pressable
                      style={[
                        styles.availabilityToggle,
                        product.isAvailable && styles.availabilityToggleActive,
                      ]}
                      onPress={() => toggleProductAvailability(product.id)}
                    >
                      <Text
                        style={[
                          styles.availabilityToggleText,
                          product.isAvailable && styles.availabilityToggleTextActive,
                        ]}
                      >
                        {product.isAvailable ? 'Available to customers' : 'Unavailable'}
                      </Text>
                    </Pressable>
                  </View>
                </View>
              ))}

              <Pressable style={styles.inlineActionButton} onPress={addProduct}>
                <Text style={styles.inlineActionButtonText}>+ Add product</Text>
              </Pressable>
            </>
          ) : (
            <>
              <View style={styles.settingRowDark}>
                <Text style={styles.settingIcon}>🍔</Text>
                <View style={styles.settingCopyWrap}>
                  <Text style={styles.settingTextDark}>
                    {(profile.products ?? []).length} products
                  </Text>
                  <Text style={styles.settingMetaDark}>
                    Your menu is visible to customers in vendor discovery.
                  </Text>
                </View>
              </View>
              {(profile.products ?? []).map((product) => (
                <View key={product.id} style={styles.settingRowDark}>
                  <Text style={styles.settingIcon}>{product.imageSymbol || '💰'}</Text>
                  <View style={styles.settingCopyWrap}>
                    <Text style={styles.settingTextDark}>{product.name}</Text>
                    <Text style={styles.settingMetaDark}>
                      {product.priceLabel} · {product.isAvailable ? 'Available' : 'Unavailable'}
                    </Text>
                  </View>
                </View>
              ))}
            </>
          )}
        </View>
      </View>

      <View style={styles.sectionCard}>
        <Text style={styles.sectionEyebrow}>Business hours</Text>
        <Text style={styles.sectionTitle}>Opening times</Text>
        <View style={styles.settingsListDark}>
          <View style={styles.settingRowDark}>
            <Text style={styles.settingIcon}>🕒</Text>
            <View style={styles.settingCopyWrap}>
              <Text style={styles.settingTextDark}>{profile.openingHours}</Text>
              <Text style={styles.settingMetaDark}>Status: {liveBusinessStatus}</Text>
            </View>
          </View>
        </View>
      </View>

      <View style={styles.sectionCard}>
        <Text style={styles.sectionEyebrow}>Live settings</Text>
        <Text style={styles.sectionTitle}>Location & live settings</Text>
        <View style={styles.settingsListDark}>
          <View style={styles.settingRowDark}>
            <Text style={styles.settingIcon}>📡</Text>
            <View style={styles.settingCopyWrap}>
              <Text style={styles.settingTextDark}>Location services</Text>
              <Text style={styles.settingMetaDark}>
                {vendorLiveState.location ? 'GPS connected' : 'Waiting for GPS permission'}
              </Text>
            </View>
          </View>
          <View style={styles.settingRowDark}>
            <Text style={styles.settingIcon}>📊</Text>
            <View style={styles.settingCopyWrap}>
              <Text style={styles.settingTextDark}>GPS hours used</Text>
              <Text style={styles.settingMetaDark}>
                {vendorLiveState.isLive ? 'Live session active now' : 'No active live session'}
              </Text>
            </View>
          </View>
          <View style={styles.settingRowDark}>
            <Text style={styles.settingIcon}>🔄</Text>
            <View style={styles.settingCopyWrap}>
              <Text style={styles.settingTextDark}>Background tracking status</Text>
              <Text style={styles.settingMetaDark}>
                {vendorLiveState.isLive
                  ? 'Foreground GPS updates are active'
                  : 'Tracking is currently turned off'}
              </Text>
            </View>
          </View>
        </View>
      </View>

      <View style={styles.sectionCard}>
        <Text style={styles.sectionEyebrow}>Settings</Text>
        <Text style={styles.sectionTitle}>App preferences</Text>
        <View style={styles.settingsListDark}>
          <View style={styles.settingRowDark}>
            <Text style={styles.settingIcon}>🔔</Text>
            <View style={styles.settingCopyWrap}>
              <Text style={styles.settingTextDark}>Notifications</Text>
              <Text style={styles.settingMetaDark}>Manage message and system alerts.</Text>
            </View>
          </View>
          <View style={styles.settingRowDark}>
            <Text style={styles.settingIcon}>🌍</Text>
            <View style={styles.settingCopyWrap}>
              <Text style={styles.settingTextDark}>Language</Text>
              <Text style={styles.settingMetaDark}>English</Text>
            </View>
          </View>
          <View style={styles.settingRowDark}>
            <Text style={styles.settingIcon}>🇳🇱</Text>
            <View style={styles.settingCopyWrap}>
              <Text style={styles.settingTextDark}>Country</Text>
              <Text style={styles.settingMetaDark}>{profile.country}</Text>
            </View>
          </View>
        </View>
      </View>

      <View style={styles.supportCard}>
        <View style={styles.supportCopyWrap}>
          <Text style={styles.sectionEyebrow}>Need help?</Text>
          <Text style={styles.sectionTitle}>Let&apos;s get it sorted</Text>
          <Text style={styles.supportText}>
            Reach support if you need help with live tracking, products or your vendor account.
          </Text>
        </View>
        <View style={styles.supportIconWrap}>
          <Text style={styles.supportIcon}>💬</Text>
        </View>
      </View>
    </View>
  );
}

function formatLiveUpdate(updatedAt: string) {
  const parsedDate = new Date(updatedAt);

  if (Number.isNaN(parsedDate.getTime())) {
    return updatedAt;
  }

  return parsedDate.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function ProfileScreen() {
  const { authRole, activeViewMode, signOut } = useAuth();
  const [vendorProfile, setVendorProfile] = useState<VendorProfileSetup | null>(null);
  const [vendorLiveState, setVendorLiveState] = useState<VendorLiveState>({
    isLive: false,
    location: null,
  });
  const [isUpdatingLiveState, setIsUpdatingLiveState] = useState(false);

  const isVendorView =
    authRole === 'vendor' || (authRole === 'admin' && activeViewMode === 'vendor');

  useFocusEffect(
    useCallback(() => {
      let isActive = true;

      async function loadVendorData() {
        const [profile, liveState] = await Promise.all([getVendorProfile(), getVendorLiveState()]);

        if (isActive) {
          setVendorProfile(profile);
          setVendorLiveState(liveState);
        }
      }

      void loadVendorData();

      return () => {
        isActive = false;
      };
    }, [])
  );

  useEffect(() => {
    if (!isVendorView || !vendorLiveState.isLive) {
      return;
    }

    let isMounted = true;
    let subscription: Location.LocationSubscription | null = null;

    async function startWatchingPosition() {
      try {
        subscription = await Location.watchPositionAsync(
          {
            accuracy: Location.Accuracy.Highest,
            timeInterval: 15000,
            distanceInterval: 25,
          },
          (position) => {
            if (!isMounted) {
              return;
            }

            const nextLiveState: VendorLiveState = {
              isLive: true,
              location: {
                latitude: position.coords.latitude,
                longitude: position.coords.longitude,
                updatedAt: new Date().toISOString(),
              },
            };

            setVendorLiveState(nextLiveState);
            void saveVendorLiveState(nextLiveState);
          }
        );
      } catch {}
    }

    void startWatchingPosition();

    return () => {
      isMounted = false;
      subscription?.remove();
    };
  }, [isVendorView, vendorLiveState.isLive]);

  async function handleResetOnboarding() {
    try {
      await clearVendorLiveState();
      await clearVendorProfile();
      await resetOnboarding();
      await signOut();
      Alert.alert(
        'Intro flow reset',
        'Start de app opnieuw om onboarding, rolkeuze, login en vendor setup opnieuw te zien.'
      );
    } catch {
      Alert.alert('Reset mislukt', 'De onboarding kon niet worden gereset. Probeer het opnieuw.');
    }
  }

  async function handleLiveToggle(nextValue: boolean) {
    if (!isVendorView) {
      return;
    }

    if (!vendorProfile) {
      Alert.alert(
        'Vendor profile required',
        'Complete your vendor profile before you go live.'
      );
      return;
    }

    setIsUpdatingLiveState(true);

    try {
      if (!nextValue) {
        const offlineState: VendorLiveState = {
          isLive: false,
          location: vendorLiveState.location,
        };
        await saveVendorLiveState(offlineState);
        setVendorLiveState(offlineState);
        Alert.alert('Go Offline', 'Live location sharing has been turned off.');
        return;
      }

      const servicesEnabled = await Location.hasServicesEnabledAsync();

      if (!servicesEnabled) {
        Alert.alert(
          'Location needed',
          'Turn on GPS on your phone to share your live location with customers.'
        );
        return;
      }

      const permission = await Location.requestForegroundPermissionsAsync();

      if (permission.status !== 'granted') {
        Alert.alert(
          'Location permission required',
          'Allow location access so customers can find your live position on the map.'
        );
        return;
      }

      const currentPosition = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Highest,
      });

      const liveState: VendorLiveState = {
        isLive: true,
        location: {
          latitude: currentPosition.coords.latitude,
          longitude: currentPosition.coords.longitude,
          updatedAt: new Date().toISOString(),
        },
      };

      await saveVendorLiveState(liveState);
      setVendorLiveState(liveState);
      Alert.alert('Go Live', 'You are now live and visible to customers on the map.');
    } catch {
      Alert.alert(
        'Could not go live',
        'We need GPS access to share your live location. Please try again.'
      );
    } finally {
      setIsUpdatingLiveState(false);
    }
  }

  function handleVendorLogout() {
    Alert.alert('Log out', 'Are you sure you want to log out?', [
      {
        text: 'Cancel',
        style: 'cancel',
      },
      {
        text: 'Log out',
        style: 'destructive',
        onPress: () => {
          void (async () => {
            try {
              const offlineState: VendorLiveState = {
                isLive: false,
                location: vendorLiveState.location,
              };

              await saveVendorLiveState(offlineState);
              setVendorLiveState(offlineState);
              await signOut();
            } catch {
              Alert.alert('Log out failed', 'We could not log you out right now. Please try again.');
            }
          })();
        },
      },
    ]);
  }

  function handleCloseVendorAccount() {
    Alert.alert(
      'Close your account?',
      'This action cannot be undone. All your data will be permanently deleted.',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Continue',
          style: 'destructive',
          onPress: () => {
            Alert.alert(
              'Final confirmation',
              'Are you sure you want to permanently close your vendor account?',
              [
                {
                  text: 'Cancel',
                  style: 'cancel',
                },
                {
                  text: 'Delete account',
                  style: 'destructive',
                  onPress: () => {
                    void (async () => {
                      try {
                        setIsUpdatingLiveState(true);
                        setVendorLiveState({
                          isLive: false,
                          location: null,
                        });
                        await clearVendorLiveState();
                        await clearVendorProfile();
                        setVendorProfile(null);
                        await signOut();
                      } catch {
                        Alert.alert(
                          'Delete account failed',
                          'We could not close your account right now. Please try again.'
                        );
                      } finally {
                        setIsUpdatingLiveState(false);
                      }
                    })();
                  },
                },
              ]
            );
          },
        },
      ]
    );
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.content}>
        {isVendorView ? (
          <>
            <View style={styles.hero}>
              <Text style={styles.heroLabel}>Vendor</Text>
              <Text style={styles.heroGreeting}>
                Hey, {vendorProfile?.firstName?.trim() || 'Michaello'}!
              </Text>
              <View style={styles.heroTopRow}>
                <View style={styles.heroCopyWrap}>
                  <Text style={styles.copy}>
                    This is your vendor control center. Review your business, products and live visibility.
                  </Text>
                </View>
                <View style={styles.avatarCircle}>
                  <Text style={styles.avatarText}>
                    {vendorProfile?.firstName?.trim()?.charAt(0).toUpperCase() || 'M'}
                  </Text>
                </View>
              </View>
            </View>

            <View style={styles.liveCard}>
              <View style={styles.liveCardTop}>
                <View style={styles.liveCardCopy}>
                  <Text style={styles.liveTitle}>Live location sharing</Text>
                  <Text style={styles.liveCopy}>
                    Turn on live mode so customers can find and track your current location.
                  </Text>
                </View>
                <Switch
                  value={vendorLiveState.isLive}
                  onValueChange={(value) => void handleLiveToggle(value)}
                  disabled={isUpdatingLiveState}
                  trackColor={{ false: '#334155', true: '#86EFAC' }}
                  thumbColor={vendorLiveState.isLive ? '#166534' : '#E2E8F0'}
                />
              </View>

              <View style={styles.liveStatusRow}>
                <View
                  style={[
                    styles.liveStatusBadge,
                    vendorLiveState.isLive ? styles.liveStatusBadgeOn : styles.liveStatusBadgeOff,
                  ]}
                >
                  <Text
                    style={[
                      styles.liveStatusText,
                      vendorLiveState.isLive ? styles.liveStatusTextOn : styles.liveStatusTextOff,
                    ]}
                  >
                    {vendorLiveState.isLive ? 'Live now' : 'Offline'}
                  </Text>
                </View>
                <Text style={styles.liveMeta}>
                  {vendorLiveState.location
                    ? `Last GPS update ${formatLiveUpdate(vendorLiveState.location.updatedAt)}`
                    : 'No live GPS update yet'}
                </Text>
              </View>

              <Text style={styles.liveHint}>
                {vendorLiveState.isLive
                  ? 'Your current device location is now used as your live map position.'
                  : 'Go live to appear on the customer map. Offline vendors are hidden from nearby discovery.'}
              </Text>
            </View>

            <VendorProfileEditor
              initialProfile={vendorProfile}
              vendorLiveState={vendorLiveState}
            />

            <View style={styles.logoutCard}>
              <Text style={styles.logoutEyebrow}>Security</Text>
              <Text style={styles.logoutTitle}>Log out</Text>
              <Text style={styles.logoutCopy}>
                Sign out safely from this device. If you are live now, your location sharing will stop automatically.
              </Text>
              <Pressable style={styles.logoutButton} onPress={handleVendorLogout}>
                <Text style={styles.logoutButtonIcon}>↪</Text>
                <Text style={styles.logoutButtonText}>Log out</Text>
              </Pressable>
            </View>

            <View style={styles.closeAccountCard}>
              <Text style={styles.closeAccountEyebrow}>Danger zone</Text>
              <Text style={styles.closeAccountTitle}>Close account</Text>
              <Text style={styles.closeAccountCopy}>
                Permanently delete your vendor account and remove your business from the app.
              </Text>
              <Pressable style={styles.closeAccountButton} onPress={handleCloseVendorAccount}>
                <TrashOutlineIcon />
                <Text style={styles.closeAccountButtonText}>Close account</Text>
              </Pressable>
            </View>

            <View style={styles.devCard}>
              <Text style={styles.devEyebrow}>Testing</Text>
              <Text style={styles.devTitle}>Replay onboarding</Text>
              <Text style={styles.devCopy}>
                Reset onboarding, role selection, login and vendor setup for a fresh test run.
              </Text>
              <Pressable style={styles.devButton} onPress={() => void handleResetOnboarding()}>
                <Text style={styles.devButtonText}>Reset intro flow</Text>
              </Pressable>
            </View>
          </>
        ) : (
          <>
            <View style={styles.hero}>
              <Text style={styles.eyebrow}>Profile</Text>
              <Text style={styles.title}>Customer settings</Text>
              <Text style={styles.copy}>
                Profile is the long-term home for account, permissions, and preferences.
              </Text>
            </View>

            <View style={styles.profileCard}>
              <Text style={styles.profileName}>Alex Customer</Text>
              <Text style={styles.profileSub}>Tracking favorite vendors across the city.</Text>

              <View style={styles.settingsList}>
                {settings.map((setting) => (
                  <View key={setting} style={styles.settingRow}>
                    <Text style={styles.settingText}>{setting}</Text>
                  </View>
                ))}
              </View>
            </View>

            <View style={styles.devCard}>
              <Text style={styles.devEyebrow}>Testing</Text>
              <Text style={styles.devTitle}>Replay onboarding</Text>
              <Text style={styles.devCopy}>
                Reset the first-run intro so you can preview the onboarding flow again.
              </Text>
              <Pressable style={styles.devButton} onPress={() => void handleResetOnboarding()}>
                <Text style={styles.devButtonText}>Reset onboarding</Text>
              </Pressable>
            </View>
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: palette.ink,
  },
  content: {
    padding: 20,
    gap: 14,
  },
  hero: {
    backgroundColor: palette.panel,
    borderRadius: 28,
    padding: 20,
    gap: 12,
  },
  heroLabel: {
    color: '#F8FAFC',
    fontSize: 16,
    fontWeight: '800',
    textAlign: 'center',
  },
  heroTopRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 16,
  },
  heroCopyWrap: {
    flex: 1,
  },
  heroGreeting: {
    color: '#FFFFFF',
    fontSize: 28,
    fontWeight: '900',
  },
  avatarCircle: {
    width: 68,
    height: 68,
    borderRadius: 999,
    backgroundColor: palette.orange,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowOpacity: 0.18,
    shadowRadius: 18,
    elevation: 8,
  },
  avatarText: {
    color: '#FFFFFF',
    fontSize: 28,
    fontWeight: '900',
  },
  eyebrow: {
    color: palette.mint,
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  title: {
    marginTop: 6,
    color: palette.cloud,
    fontSize: 28,
    fontWeight: '800',
  },
  copy: {
    marginTop: 10,
    color: '#B7C4D8',
    lineHeight: 21,
  },
  profileCard: {
    backgroundColor: '#F5F1E8',
    borderRadius: 28,
    padding: 20,
  },
  profileName: {
    color: palette.ink,
    fontSize: 24,
    fontWeight: '800',
  },
  profileSub: {
    marginTop: 8,
    color: '#475569',
    lineHeight: 21,
  },
  settingsList: {
    marginTop: 18,
    gap: 10,
  },
  settingRow: {
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    paddingHorizontal: 16,
    paddingVertical: 14,
  },
  settingText: {
    color: '#334155',
    fontWeight: '700',
  },
  vendorCard: {
    backgroundColor: palette.panel,
    borderRadius: 28,
    padding: 20,
    gap: 14,
  },
  vendorStack: {
    gap: 14,
  },
  sectionCard: {
    backgroundColor: '#25221E',
    borderRadius: 28,
    padding: 20,
    gap: 14,
  },
  sectionEyebrow: {
    color: '#D8C7A8',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  sectionTitle: {
    color: '#FFFFFF',
    fontSize: 26,
    fontWeight: '900',
  },
  collapseHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 16,
  },
  collapseHeaderCopy: {
    flex: 1,
    gap: 4,
  },
  collapseIcon: {
    color: '#FFFFFF',
    fontSize: 28,
    fontWeight: '400',
    lineHeight: 28,
  },
  collapsedSummary: {
    color: '#D4DEEA',
    fontSize: 15,
    lineHeight: 22,
  },
  liveCard: {
    backgroundColor: '#1E2E22',
    borderRadius: 28,
    padding: 20,
    gap: 14,
    borderWidth: 1,
    borderColor: 'rgba(134,239,172,0.18)',
    shadowColor: '#22C55E',
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowOpacity: 0.12,
    shadowRadius: 20,
    elevation: 10,
  },
  liveCardTop: {
    flexDirection: 'row',
    gap: 14,
    alignItems: 'center',
  },
  liveCardCopy: {
    flex: 1,
  },
  liveTitle: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: '800',
  },
  liveCopy: {
    marginTop: 8,
    color: '#B7C4D8',
    lineHeight: 21,
  },
  liveStatusRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 12,
    flexWrap: 'wrap',
  },
  liveStatusBadge: {
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 7,
  },
  liveStatusBadgeOn: {
    backgroundColor: '#DCFCE7',
  },
  liveStatusBadgeOff: {
    backgroundColor: '#E2E8F0',
  },
  liveStatusText: {
    fontSize: 12,
    fontWeight: '800',
  },
  liveStatusTextOn: {
    color: '#166534',
  },
  liveStatusTextOff: {
    color: '#475569',
  },
  liveMeta: {
    color: '#B7C4D8',
    fontSize: 12,
    fontWeight: '700',
  },
  liveHint: {
    color: '#D4DEEA',
    lineHeight: 21,
  },
  vendorHeaderRow: {
    flexDirection: 'row',
    gap: 14,
    alignItems: 'flex-start',
  },
  vendorHeaderCopy: {
    flex: 1,
  },
  vendorEyebrow: {
    color: palette.mint,
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  vendorTitle: {
    marginTop: 6,
    color: palette.cloud,
    fontSize: 26,
    fontWeight: '800',
  },
  vendorCopy: {
    marginTop: 10,
    color: '#B7C4D8',
    lineHeight: 21,
  },
  editButton: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 999,
    paddingHorizontal: 14,
    paddingVertical: 10,
  },
  editButtonActive: {
    backgroundColor: '#FDE68A',
  },
  editButtonText: {
    color: palette.cloud,
    fontSize: 12,
    fontWeight: '800',
  },
  editButtonTextActive: {
    color: '#92400E',
  },
  vendorBlock: {
    backgroundColor: palette.panelAlt,
    borderRadius: 22,
    padding: 16,
    gap: 10,
  },
  blockLabel: {
    color: palette.mint,
    fontSize: 11,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  vendorIdentityRow: {
    flexDirection: 'row',
    gap: 14,
    alignItems: 'center',
  },
  vendorLogoBox: {
    width: 58,
    height: 58,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.10)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  vendorLogoText: {
    fontSize: 26,
  },
  vendorIdentityCopy: {
    flex: 1,
  },
  blockTitle: {
    color: palette.cloud,
    fontSize: 19,
    fontWeight: '800',
  },
  blockText: {
    color: '#D4DEEA',
    lineHeight: 21,
  },
  settingsListDark: {
    gap: 10,
  },
  settingRowDark: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: '#34302B',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 15,
  },
  settingIcon: {
    fontSize: 18,
  },
  settingCopyWrap: {
    flex: 1,
  },
  settingTextDark: {
    color: '#F8FAFC',
    fontSize: 16,
    fontWeight: '700',
  },
  settingMetaDark: {
    marginTop: 4,
    color: '#C0CAD8',
    fontSize: 13,
    lineHeight: 18,
  },
  productEditorCard: {
    backgroundColor: '#34302B',
    borderRadius: 20,
    padding: 14,
    gap: 10,
  },
  productEditorHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    gap: 12,
  },
  productEditorTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    flex: 1,
  },
  productIconBubble: {
    width: 40,
    height: 40,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  productIconBubbleText: {
    fontSize: 18,
  },
  productEditorActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  productSortText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '900',
  },
  removeProductText: {
    color: '#FCA5A5',
    fontSize: 12,
    fontWeight: '800',
  },
  inlineActionButton: {
    alignSelf: 'flex-start',
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.08)',
    paddingHorizontal: 14,
    paddingVertical: 10,
  },
  inlineActionButtonText: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '800',
  },
  availabilityToggle: {
    minHeight: 46,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 14,
  },
  availabilityToggleActive: {
    backgroundColor: '#DCFCE7',
  },
  availabilityToggleText: {
    color: '#E2E8F0',
    fontSize: 13,
    fontWeight: '800',
  },
  availabilityToggleTextActive: {
    color: '#166534',
  },
  formStack: {
    gap: 10,
  },
  formRow: {
    flexDirection: 'row',
    gap: 10,
  },
  formRowMain: {
    flex: 1,
  },
  formRowSide: {
    width: 120,
  },
  profileInput: {
    minHeight: 54,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
    backgroundColor: 'rgba(255,255,255,0.08)',
    paddingHorizontal: 14,
    color: palette.cloud,
    fontSize: 15,
  },
  profileTextArea: {
    minHeight: 118,
    paddingTop: 14,
    paddingBottom: 14,
  },
  saveButton: {
    marginTop: 2,
    backgroundColor: palette.mint,
    borderRadius: 999,
    paddingVertical: 14,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#0F172A',
    fontSize: 14,
    fontWeight: '800',
  },
  supportCard: {
    backgroundColor: '#3A3631',
    borderRadius: 28,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  supportCopyWrap: {
    flex: 1,
    gap: 6,
  },
  supportText: {
    color: '#D4DEEA',
    lineHeight: 21,
  },
  supportIconWrap: {
    width: 64,
    height: 64,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  supportIcon: {
    fontSize: 30,
  },
  devCard: {
    backgroundColor: '#F5F1E8',
    borderRadius: 28,
    padding: 20,
    gap: 10,
  },
  devEyebrow: {
    color: palette.orange,
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  devTitle: {
    color: palette.ink,
    fontSize: 24,
    fontWeight: '800',
  },
  devCopy: {
    color: '#475569',
    lineHeight: 21,
  },
  devButton: {
    marginTop: 4,
    alignSelf: 'flex-start',
    backgroundColor: palette.ink,
    borderRadius: 999,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  devButtonText: {
    color: palette.cloud,
    fontSize: 13,
    fontWeight: '800',
  },
  logoutCard: {
    backgroundColor: '#2A1618',
    borderRadius: 28,
    padding: 20,
    gap: 10,
    borderWidth: 1,
    borderColor: 'rgba(248,113,113,0.18)',
  },
  logoutEyebrow: {
    color: '#FDA4AF',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  logoutTitle: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: '800',
  },
  logoutCopy: {
    color: '#FBCFE8',
    lineHeight: 21,
  },
  logoutButton: {
    marginTop: 4,
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: '#DC2626',
    borderRadius: 999,
    paddingHorizontal: 18,
    paddingVertical: 12,
  },
  logoutButtonIcon: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '900',
  },
  logoutButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '800',
  },
  closeAccountCard: {
    backgroundColor: '#140E0E',
    borderRadius: 28,
    padding: 20,
    gap: 10,
    borderWidth: 1,
    borderColor: 'rgba(252,165,165,0.20)',
  },
  closeAccountEyebrow: {
    color: '#FCA5A5',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  closeAccountTitle: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: '800',
  },
  closeAccountCopy: {
    color: '#FECACA',
    lineHeight: 21,
  },
  closeAccountButton: {
    marginTop: 4,
    alignSelf: 'flex-start',
    minHeight: 46,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 4,
  },
  closeAccountButtonText: {
    color: '#FCA5A5',
    fontSize: 14,
    fontWeight: '800',
  },
  trashIconWrap: {
    width: 18,
    height: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  trashIconLid: {
    position: 'absolute',
    top: 2,
    width: 12,
    height: 2,
    borderRadius: 2,
    backgroundColor: '#FCA5A5',
  },
  trashIconHandle: {
    position: 'absolute',
    top: 0,
    width: 6,
    height: 3,
    borderWidth: 1.4,
    borderBottomWidth: 0,
    borderColor: '#FCA5A5',
    borderTopLeftRadius: 3,
    borderTopRightRadius: 3,
    backgroundColor: 'transparent',
  },
  trashIconBody: {
    position: 'absolute',
    top: 5,
    width: 10,
    height: 10,
    borderWidth: 1.6,
    borderColor: '#FCA5A5',
    borderBottomLeftRadius: 2,
    borderBottomRightRadius: 2,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 2,
  },
  trashIconLine: {
    width: 1.4,
    height: 5,
    borderRadius: 2,
    backgroundColor: '#FCA5A5',
  },
});
