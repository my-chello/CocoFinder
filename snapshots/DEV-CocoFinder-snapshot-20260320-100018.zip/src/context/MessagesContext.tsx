import { createContext, ReactNode, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { chatMessages, conversationSummaries } from '../data/mockMessages';
import { useVendorData } from '../hooks/useVendorData';
import { formatRelativeTimestamp, getCurrentSupabaseUserId, isMissingRelationError } from '../lib/social';
import { supabase } from '../lib/supabase';
import type { ChatMessage, ConversationSummary } from '../types/messages';

type MessagesContextValue = {
  conversations: ConversationSummary[];
  getConversationById: (conversationId: string) => ConversationSummary | undefined;
  getMessagesForConversation: (conversationId: string) => ChatMessage[];
  openConversationForVendor: (vendorId: string) => string;
  sendMessage: (conversationId: string, body: string) => void;
  markConversationRead: (conversationId: string) => void;
  deleteConversation: (conversationId: string) => void;
};

const MessagesContext = createContext<MessagesContextValue | null>(null);

function buildConversationSummary(vendorId: string, vendorRecords: ReturnType<typeof useVendorData>['vendorTabRecords']): ConversationSummary {
  const vendorRecord = vendorRecords.find((record) => record.vendor.id === vendorId);

  if (!vendorRecord) {
    throw new Error(`Vendor ${vendorId} not found for conversation`);
  }

  return {
    id: `conversation-${vendorId}`,
    vendorId,
    customerUserId: 'user-customer-alex',
    vendorName: vendorRecord.vendor.businessName,
    vendorCategory: vendorRecord.vendor.category,
    vendorSymbol: vendorRecord.vendor.imageSymbol ?? vendorRecord.vendor.imageHint,
    lastMessagePreview: '',
    lastMessageAt: '',
    lastMessageSortMinutesAgo: Number.MAX_SAFE_INTEGER,
    unreadCount: 0,
    isVendorLive: vendorRecord.vendor.liveStatus === 'live',
    isVisibleInInbox: false,
  };
}

export function MessagesProvider({ children }: { children: ReactNode }) {
  const { vendorTabRecords } = useVendorData();
  const [conversations, setConversations] = useState<ConversationSummary[]>(conversationSummaries);
  const [messages, setMessages] = useState<ChatMessage[]>(chatMessages);

  const loadFromSupabase = useCallback(async () => {
    try {
      const userId = await getCurrentSupabaseUserId();

      if (!userId) {
        return;
      }

      const [{ data: conversationRows, error: conversationsError }, { data: messageRows, error: messagesError }] =
        await Promise.all([
          supabase
            .from('app_conversations')
            .select('id,vendor_id,customer_user_id,customer_unread_count,last_message_preview,last_message_at,customer_deleted,updated_at')
            .eq('customer_user_id', userId),
          supabase
            .from('app_messages')
            .select('id,conversation_id,sender_role,sender_name,body,sent_at')
            .order('sent_at', { ascending: true }),
        ]);

      if (conversationsError || messagesError) {
        if (conversationsError && !isMissingRelationError(conversationsError.message)) {
          console.error('Failed to load conversations', conversationsError);
        }
        if (messagesError && !isMissingRelationError(messagesError.message)) {
          console.error('Failed to load messages', messagesError);
        }
        return;
      }

      const nextConversations = (conversationRows ?? []).map((conversation) => {
        const vendorRecord = vendorTabRecords.find((record) => record.vendor.id === conversation.vendor_id);

        return {
          id: conversation.id as string,
          vendorId: conversation.vendor_id as string,
          customerUserId: conversation.customer_user_id as string,
          vendorName: vendorRecord?.vendor.businessName ?? 'Vendor',
          vendorCategory: vendorRecord?.vendor.category ?? 'Unknown',
          vendorSymbol: vendorRecord?.vendor.imageSymbol ?? vendorRecord?.vendor.imageHint,
          lastMessagePreview: (conversation.last_message_preview as string) ?? '',
          lastMessageAt: conversation.last_message_at
            ? formatRelativeTimestamp(conversation.last_message_at as string)
            : '',
          lastMessageSortMinutesAgo: conversation.last_message_at
            ? Math.max(
                0,
                Math.round((Date.now() - new Date(conversation.last_message_at as string).getTime()) / 60000)
              )
            : Number.MAX_SAFE_INTEGER,
          unreadCount: (conversation.customer_unread_count as number) ?? 0,
          isVendorLive: vendorRecord?.vendor.liveStatus === 'live',
          isVisibleInInbox: !(conversation.customer_deleted as boolean),
        };
      });

      const visibleConversationIds = new Set(nextConversations.map((conversation) => conversation.id));
      const nextMessages = (messageRows ?? [])
        .filter((message) => visibleConversationIds.has(message.conversation_id as string))
        .map((message) => ({
          id: message.id as string,
          conversationId: message.conversation_id as string,
          senderRole: message.sender_role as 'customer' | 'vendor',
          senderName: message.sender_name as string,
          body: message.body as string,
          sentAt: formatRelativeTimestamp(message.sent_at as string),
        }));

      if (nextConversations.length > 0) {
        setConversations(nextConversations);
        setMessages(nextMessages);
      }
    } catch {}
  }, [vendorTabRecords]);

  useEffect(() => {
    void loadFromSupabase();
  }, [loadFromSupabase]);

  useEffect(() => {
    const channel = supabase
      .channel('customer-messages-realtime')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'app_conversations' },
        () => {
          void loadFromSupabase();
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'app_messages' },
        () => {
          void loadFromSupabase();
        }
      )
      .subscribe();

    return () => {
      void supabase.removeChannel(channel);
    };
  }, [loadFromSupabase]);

  const sortedVisibleConversations = useMemo(
    () =>
      [...conversations]
        .filter((conversation) => conversation.isVisibleInInbox)
        .sort((left, right) => left.lastMessageSortMinutesAgo - right.lastMessageSortMinutesAgo),
    [conversations]
  );

  const getConversationById = useCallback((conversationId: string) => {
    return conversations.find((conversation) => conversation.id === conversationId);
  }, [conversations]);

  const getMessagesForConversation = useCallback((conversationId: string) => {
    return messages.filter((message) => message.conversationId === conversationId);
  }, [messages]);

  const openConversationForVendor = useCallback((vendorId: string) => {
    const existingConversation = conversations.find((conversation) => conversation.vendorId === vendorId);

    if (existingConversation) {
      setConversations((current) =>
        current.map((conversation) =>
          conversation.id === existingConversation.id
            ? { ...conversation, isVisibleInInbox: true }
            : conversation
        )
      );
      return existingConversation.id;
    }

    const nextConversation = buildConversationSummary(vendorId, vendorTabRecords);

    setConversations((current) => [nextConversation, ...current]);

    void (async () => {
      try {
        const userId = await getCurrentSupabaseUserId();

        if (!userId) {
          return;
        }

        const { error } = await supabase.from('app_conversations').upsert(
          {
            id: nextConversation.id,
            vendor_id: vendorId,
            customer_user_id: userId,
            customer_deleted: false,
            customer_unread_count: 0,
            last_message_preview: '',
            last_message_at: null,
            updated_at: new Date().toISOString(),
          },
          {
            onConflict: 'id',
          }
        );

        if (error && !isMissingRelationError(error.message)) {
          console.error('Failed to create conversation', error);
        }
      } catch {}
    })();

    return nextConversation.id;
  }, [conversations, vendorTabRecords]);

  const sendMessage = useCallback((conversationId: string, body: string) => {
    const trimmedBody = body.trim();

    if (!trimmedBody) {
      return;
    }

    const nextMessage: ChatMessage = {
      id: `message-local-${Date.now()}`,
      conversationId,
      senderRole: 'customer',
      senderName: 'Alex Customer',
      body: trimmedBody,
      sentAt: 'Just now',
    };

    setMessages((current) => [...current, nextMessage]);
    setConversations((current) =>
      current.map((conversation) =>
        conversation.id === conversationId
          ? {
              ...conversation,
              lastMessagePreview: trimmedBody,
              lastMessageAt: 'Just now',
              lastMessageSortMinutesAgo: 0,
              unreadCount: 0,
              isVisibleInInbox: true,
            }
          : {
              ...conversation,
              lastMessageSortMinutesAgo:
                conversation.lastMessageSortMinutesAgo === Number.MAX_SAFE_INTEGER
                  ? Number.MAX_SAFE_INTEGER
                  : conversation.lastMessageSortMinutesAgo + 1,
            }
      )
    );

    void (async () => {
      try {
        const userId = await getCurrentSupabaseUserId();

        if (!userId) {
          return;
        }

        const nowIso = new Date().toISOString();
        const { error: conversationError } = await supabase.from('app_conversations').upsert(
          {
            id: conversationId,
            customer_user_id: userId,
            vendor_id:
              conversations.find((conversation) => conversation.id === conversationId)?.vendorId ?? '',
            customer_deleted: false,
            customer_unread_count: 0,
            last_message_preview: trimmedBody,
            last_message_at: nowIso,
            updated_at: nowIso,
          },
          { onConflict: 'id' }
        );

        if (conversationError && !isMissingRelationError(conversationError.message)) {
          console.error('Failed to update conversation', conversationError);
        }

        const { error: messageError } = await supabase.from('app_messages').insert({
          id: nextMessage.id,
          conversation_id: conversationId,
          sender_role: 'customer',
          sender_name: 'Alex Customer',
          body: trimmedBody,
          sent_at: nowIso,
        });

        if (messageError && !isMissingRelationError(messageError.message)) {
          console.error('Failed to save message', messageError);
        }
      } catch {}
    })();
  }, [conversations]);

  const markConversationRead = useCallback((conversationId: string) => {
    setConversations((current) =>
      current.map((conversation) =>
        conversation.id === conversationId
          ? {
              ...conversation,
              unreadCount: 0,
            }
          : conversation
      )
    );

    void (async () => {
      try {
        const { error } = await supabase
          .from('app_conversations')
          .update({ customer_unread_count: 0, customer_deleted: false, updated_at: new Date().toISOString() })
          .eq('id', conversationId);

        if (error && !isMissingRelationError(error.message)) {
          console.error('Failed to mark conversation as read', error);
        }
      } catch {}
    })();
  }, []);

  const deleteConversation = useCallback((conversationId: string) => {
    setConversations((current) =>
      current.map((conversation) =>
        conversation.id === conversationId
          ? {
              ...conversation,
              isVisibleInInbox: false,
            }
          : conversation
      )
    );

    void (async () => {
      try {
        const { error } = await supabase
          .from('app_conversations')
          .update({ customer_deleted: true, updated_at: new Date().toISOString() })
          .eq('id', conversationId);

        if (error && !isMissingRelationError(error.message)) {
          console.error('Failed to hide conversation', error);
        }
      } catch {}
    })();
  }, []);

  const value = useMemo(
    () => ({
      conversations: sortedVisibleConversations,
      getConversationById,
      getMessagesForConversation,
      openConversationForVendor,
      sendMessage,
      markConversationRead,
      deleteConversation,
    }),
    [
      deleteConversation,
      getConversationById,
      getMessagesForConversation,
      markConversationRead,
      openConversationForVendor,
      sendMessage,
      sortedVisibleConversations,
    ]
  );

  return (
    <MessagesContext.Provider value={value}>
      {children}
    </MessagesContext.Provider>
  );
}

export function useMessages() {
  const context = useContext(MessagesContext);

  if (!context) {
    throw new Error('useMessages must be used within a MessagesProvider');
  }

  return context;
}
