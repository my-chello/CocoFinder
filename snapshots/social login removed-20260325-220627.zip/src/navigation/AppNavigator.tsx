import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { StyleSheet, Text, View } from 'react-native';
import { palette } from '../config/theme';
import { FavoritesScreen } from '../screens/customer/FavoritesScreen';
import { MapScreen } from '../screens/customer/MapScreen';
import { ProfileScreen } from '../screens/customer/ProfileScreen';
import { MessagesNavigator } from './MessagesNavigator';
import { VendorsNavigator } from './VendorsNavigator';

const Tab = createBottomTabNavigator();

const navTheme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    background: palette.ink,
    card: palette.panel,
    text: palette.cloud,
    primary: palette.mint,
    border: palette.panelAlt,
  },
};

const iconMap = {
  Map: '◎',
  Vendors: '▤',
  Messages: '✉',
  Favorites: '♥',
  Profile: '👤',
} as const;

export function AppNavigator() {
  return (
    <NavigationContainer theme={navTheme}>
      <Tab.Navigator
        initialRouteName="Map"
        screenOptions={({ route }) => ({
          headerShown: false,
          tabBarShowLabel: true,
          tabBarStyle: {
            position: 'absolute',
            left: 16,
            right: 16,
            bottom: 16,
            height: 82,
            borderTopWidth: 0,
            borderRadius: 28,
            backgroundColor: 'rgba(247, 244, 237, 0.98)',
            paddingBottom: 12,
            paddingTop: 10,
            paddingHorizontal: 8,
            shadowColor: '#000000',
            shadowOffset: {
              width: 0,
              height: 14,
            },
            shadowOpacity: 0.12,
            shadowRadius: 22,
            elevation: 10,
          },
          tabBarLabelStyle: {
            fontSize: 11,
            fontWeight: '800',
            marginTop: 2,
          },
          tabBarItemStyle: {
            borderRadius: 22,
            marginHorizontal: 2,
          },
          tabBarActiveTintColor: '#111827',
          tabBarInactiveTintColor: '#94A3B8',
          tabBarIcon: ({ color, focused }) => (
            <View style={[styles.iconWrap, focused && styles.iconWrapActive]}>
              <Text style={[styles.icon, { color }]}>{iconMap[route.name as keyof typeof iconMap]}</Text>
            </View>
          ),
        })}
      >
        <Tab.Screen name="Map" component={MapScreen} />
        <Tab.Screen
          name="Vendors"
          component={VendorsNavigator}
          listeners={({ navigation }) => ({
            tabPress: () => {
              navigation.navigate('Vendors', {
                screen: 'VendorsList',
              });
            },
          })}
        />
        <Tab.Screen
          name="Messages"
          component={MessagesNavigator}
          listeners={({ navigation }) => ({
            tabPress: () => {
              navigation.navigate('Messages', {
                screen: 'ConversationsList',
              });
            },
          })}
        />
        <Tab.Screen name="Favorites" component={FavoritesScreen} />
        <Tab.Screen name="Profile" component={ProfileScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  iconWrap: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconWrapActive: {
    backgroundColor: '#FFF1E8',
  },
  icon: {
    fontSize: 16,
    fontWeight: '800',
  },
});
