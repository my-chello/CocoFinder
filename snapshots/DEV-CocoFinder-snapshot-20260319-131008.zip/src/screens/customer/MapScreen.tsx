import { useEffect, useRef, useState } from 'react';
import { useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Keyboard, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import MapView, { Circle, Marker, PROVIDER_GOOGLE, Region } from 'react-native-maps';
import * as Location from 'expo-location';
import { palette } from '../../config/theme';
import { vendorTabRecords } from '../../data/mockVendors';
import { useDebouncedValue } from '../../hooks/useDebouncedValue';
import { searchVendorRecords } from '../../lib/search';

const filterOptions = [
  'Coffee',
  'Food Truck',
  'Ice Cream',
  'Drinks',
  'Market',
  'Dutch Snacks',
  'Coconut',
  'Other',
] as const;
type FilterOption = (typeof filterOptions)[number];
const filterIcons: Record<FilterOption, string> = {
  Coffee: '☕',
  'Food Truck': '🚚',
  'Ice Cream': '🍦',
  Drinks: '🥤',
  Market: '🧺',
  'Dutch Snacks': '🇳🇱',
  Coconut: '🥥',
  Other: '✨',
};
const distanceOptions = [50, 100, 500, 1000] as const;
type DistanceOption = (typeof distanceOptions)[number];

const defaultRegion: Region = {
  latitude: 52.3676,
  longitude: 4.9041,
  latitudeDelta: 0.045,
  longitudeDelta: 0.045,
};

function vendorMatchesFilter(
  record: (typeof vendorTabRecords)[number],
  filterKey: FilterOption
): boolean {
  const category = record.vendor.category.toLowerCase();

  switch (filterKey) {
    case 'Coffee':
      return category.includes('coffee');
    case 'Food Truck':
      return category.includes('truck') || category.includes('bbq') || category.includes('food');
    case 'Ice Cream':
      return (
        category.includes('ice cream') ||
        category.includes('dessert') ||
        record.vendor.tags.some((tag) => tag.toLowerCase().includes('ice'))
      );
    case 'Drinks':
      return (
        category.includes('drink') ||
        category.includes('coconut') ||
        record.vendor.tags.some((tag) => tag.toLowerCase().includes('water'))
      );
    case 'Coconut':
      return (
        category.includes('coconut') ||
        record.vendor.tags.some((tag) => tag.toLowerCase().includes('coconut'))
      );
    case 'Market':
      return category.includes('market') || category.includes('produce');
    case 'Dutch Snacks':
      return (
        category.includes('dutch snacks') ||
        record.vendor.tags.some((tag) => {
          const normalizedTag = tag.toLowerCase();

          return (
            normalizedTag.includes('dutch') ||
            normalizedTag.includes('stroopwafel') ||
            normalizedTag.includes('fries') ||
            normalizedTag.includes('herring')
          );
        })
      );
    case 'Other':
      return !filterOptions
        .filter((option) => option !== 'Other')
        .some((option) => vendorMatchesFilter(record, option));
    default:
      return false;
  }
}

function distanceLabel(distanceMeters: DistanceOption) {
  return distanceMeters >= 1000 ? `${distanceMeters / 1000} km` : `${distanceMeters} m`;
}

function getDistanceMeters(
  from: { latitude: number; longitude: number },
  to: { latitude: number; longitude: number }
) {
  const earthRadiusMeters = 6371000;
  const dLat = ((to.latitude - from.latitude) * Math.PI) / 180;
  const dLon = ((to.longitude - from.longitude) * Math.PI) / 180;
  const fromLat = (from.latitude * Math.PI) / 180;
  const toLat = (to.latitude * Math.PI) / 180;

  const haversine =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(fromLat) *
      Math.cos(toLat) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);

  return 2 * earthRadiusMeters * Math.atan2(Math.sqrt(haversine), Math.sqrt(1 - haversine));
}

export function MapScreen() {
  const navigation = useNavigation<any>();
  const mapRef = useRef<MapView | null>(null);
  const [region, setRegion] = useState<Region>(defaultRegion);
  const [hasUserLocation, setHasUserLocation] = useState(false);
  const [userCoordinates, setUserCoordinates] = useState<{
    latitude: number;
    longitude: number;
  } | null>(null);
  const [isCenteredOnUser, setIsCenteredOnUser] = useState(true);
  const [selectedVendorId, setSelectedVendorId] = useState<string | null>(null);
  const [searchText, setSearchText] = useState('');
  const [isFilterSheetOpen, setIsFilterSheetOpen] = useState(false);
  const [activeFilters, setActiveFilters] = useState<FilterOption[]>([]);
  const [pendingFilters, setPendingFilters] = useState<FilterOption[]>([]);
  const [activeDistanceMeters, setActiveDistanceMeters] = useState<DistanceOption | null>(null);
  const [pendingDistanceMeters, setPendingDistanceMeters] = useState<DistanceOption | null>(null);
  const debouncedSearchText = useDebouncedValue(searchText, 300);
  const nearbyLiveVendors = vendorTabRecords.filter(
    (record) => record.vendor.liveStatus === 'live' && record.vendor.distanceKm <= 2
  );
  const normalizedSearch = debouncedSearchText.trim().toLowerCase();
  const distanceFilteredVendors =
    activeDistanceMeters && userCoordinates
      ? nearbyLiveVendors.filter((record) => {
          if (!record.latestLocation) {
            return false;
          }

          return (
            getDistanceMeters(userCoordinates, {
              latitude: record.latestLocation.latitude,
              longitude: record.latestLocation.longitude,
            }) <= activeDistanceMeters
          );
        })
      : nearbyLiveVendors;
  const categoryFilteredVendors =
    activeFilters.length > 0
      ? distanceFilteredVendors.filter((record) =>
          activeFilters.some((filterKey) => vendorMatchesFilter(record, filterKey))
        )
      : distanceFilteredVendors;
  const searchResults = searchVendorRecords(categoryFilteredVendors, normalizedSearch);
  const filteredVendors = normalizedSearch
    ? searchResults.map((result) => result.record)
    : categoryFilteredVendors;
  const selectedVendor =
    filteredVendors.find((record) => record.vendor.id === selectedVendorId) ??
    categoryFilteredVendors.find((record) => record.vendor.id === selectedVendorId) ??
    null;
  const pendingDistanceFilteredVendors =
    pendingDistanceMeters && userCoordinates
      ? nearbyLiveVendors.filter((record) => {
          if (!record.latestLocation) {
            return false;
          }

          return (
            getDistanceMeters(userCoordinates, {
              latitude: record.latestLocation.latitude,
              longitude: record.latestLocation.longitude,
            }) <= pendingDistanceMeters
          );
        })
      : nearbyLiveVendors;
  const pendingCategoryFilteredVendors =
    pendingFilters.length > 0
      ? pendingDistanceFilteredVendors.filter((record) =>
          pendingFilters.some((filterKey) => vendorMatchesFilter(record, filterKey))
        )
      : pendingDistanceFilteredVendors;
  const pendingFilteredVendors = normalizedSearch
    ? searchVendorRecords(pendingCategoryFilteredVendors, normalizedSearch).map(
        (result) => result.record
      )
    : pendingCategoryFilteredVendors;
  const coceroVendorId = 'vendor-cocero';
  const truckIPanVendorId = 'vendor-truck-i-pan-almere';
  function togglePendingFilter(filterKey: FilterOption) {
    setPendingFilters((current) =>
      current.includes(filterKey)
        ? current.filter((item) => item !== filterKey)
        : [...current, filterKey]
    );
  }

  function openFilterSheet() {
    Keyboard.dismiss();
    setPendingFilters(activeFilters);
    setPendingDistanceMeters(activeDistanceMeters);
    setIsFilterSheetOpen(true);
  }

  function applyFilters() {
    setActiveFilters(pendingFilters);
    setActiveDistanceMeters(pendingDistanceMeters);
    setSelectedVendorId(null);
    setIsFilterSheetOpen(false);
  }

  function resetFilters() {
    setPendingFilters([]);
    setActiveFilters([]);
    setPendingDistanceMeters(null);
    setActiveDistanceMeters(null);
    setSelectedVendorId(null);
    setIsFilterSheetOpen(false);
  }

  function updateCenteredState(nextRegion: Region) {
    if (!userCoordinates) {
      setIsCenteredOnUser(true);
      return;
    }

    const distanceFromUser = getDistanceMeters(userCoordinates, {
      latitude: nextRegion.latitude,
      longitude: nextRegion.longitude,
    });
    setIsCenteredOnUser(distanceFromUser <= 60);
  }

  async function recenterMap() {
    if (!userCoordinates) {
      return;
    }

    const nextRegion: Region = {
      latitude: userCoordinates.latitude,
      longitude: userCoordinates.longitude,
      latitudeDelta: 0.02,
      longitudeDelta: 0.02,
    };

    mapRef.current?.animateToRegion(nextRegion, 300);
    mapRef.current?.animateCamera(
      {
        center: {
          latitude: userCoordinates.latitude,
          longitude: userCoordinates.longitude,
        },
        pitch: 0,
        heading: 0,
        zoom: 16,
      },
      { duration: 300 }
    );
    setRegion(nextRegion);
    setIsCenteredOnUser(true);
  }

  async function loadLocation(isMountedRef?: { current: boolean }) {
    try {
      const permission = await Location.requestForegroundPermissionsAsync();

      if (isMountedRef && !isMountedRef.current) {
        return;
      }

      if (permission.status !== 'granted') {
        setRegion(defaultRegion);
        setHasUserLocation(false);
        return;
      }

      const currentPosition = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });

      if (isMountedRef && !isMountedRef.current) {
        return;
      }

      const nextRegion: Region = {
        latitude: currentPosition.coords.latitude,
        longitude: currentPosition.coords.longitude,
        latitudeDelta: 0.02,
        longitudeDelta: 0.02,
      };

      setRegion(nextRegion);
      setHasUserLocation(true);
      setUserCoordinates({
        latitude: currentPosition.coords.latitude,
        longitude: currentPosition.coords.longitude,
      });
      setIsCenteredOnUser(true);
    } catch {
      if (isMountedRef && !isMountedRef.current) {
        return;
      }

      setRegion(defaultRegion);
      setHasUserLocation(false);
      setUserCoordinates(null);
      setIsCenteredOnUser(true);
    }
  }

  useEffect(() => {
    const isMountedRef = { current: true };

    void loadLocation(isMountedRef);

    return () => {
      isMountedRef.current = false;
    };
  }, []);

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <View style={styles.mapSurface}>
          <MapView
            ref={mapRef}
            style={styles.map}
            provider={Platform.OS === 'android' ? PROVIDER_GOOGLE : undefined}
            initialRegion={region}
            region={region}
            showsCompass={false}
            showsUserLocation={hasUserLocation}
            showsMyLocationButton={false}
            followsUserLocation={false}
            onRegionChangeComplete={(nextRegion) => {
              setRegion(nextRegion);
              updateCenteredState(nextRegion);
            }}
          >
            {hasUserLocation && userCoordinates && activeDistanceMeters ? (
              <Circle
                center={userCoordinates}
                radius={activeDistanceMeters}
                fillColor="rgba(126,224,183,0.14)"
                strokeColor="rgba(126,224,183,0.55)"
                strokeWidth={2}
              />
            ) : null}
            {filteredVendors.map((record) =>
              record.latestLocation ? (
                <Marker
                  key={record.vendor.id}
                  coordinate={{
                    latitude: record.latestLocation.latitude,
                    longitude: record.latestLocation.longitude,
                  }}
                  title={record.vendor.businessName}
                  description={`${record.vendor.category} · ${record.vendor.distanceKm} km away`}
                    onPress={() => setSelectedVendorId(record.vendor.id)}
                >
                  <View style={styles.vendorMarkerWrap}>
                    <View
                      style={[
                        styles.vendorMarker,
                        record.vendor.id === coceroVendorId && styles.vendorMarkerCocero,
                        record.vendor.id === truckIPanVendorId && styles.vendorMarkerTruck,
                      ]}
                    >
                      <Text
                        style={[
                          styles.vendorMarkerText,
                          record.vendor.id === coceroVendorId && styles.vendorMarkerTextCocero,
                          record.vendor.id === truckIPanVendorId &&
                            styles.vendorMarkerTextTruck,
                        ]}
                      >
                        {record.vendor.imageSymbol ?? record.vendor.imageHint}
                      </Text>
                    </View>
                    <View
                      style={[
                        styles.vendorMarkerPointer,
                        record.vendor.id === coceroVendorId && styles.vendorMarkerPointerCocero,
                        record.vendor.id === truckIPanVendorId &&
                          styles.vendorMarkerPointerTruck,
                      ]}
                    />
                  </View>
                </Marker>
              ) : null
            )}
          </MapView>

          <View style={styles.searchRow}>
            <View style={styles.searchBar}>
              <TextInput
                value={searchText}
                onChangeText={setSearchText}
                placeholder="Search vendor by name"
                placeholderTextColor="#6B7280"
                style={styles.searchInput}
              />
              {normalizedSearch ? (
                <Pressable
                  style={styles.clearSearchButton}
                  onPress={() => {
                    setSearchText('');
                    setSelectedVendorId(null);
                  }}
                >
                  <Text style={styles.clearSearchButtonText}>X</Text>
                </Pressable>
              ) : null}
            </View>
            <Pressable
              style={[
                styles.filterButton,
                (activeFilters.length > 0 || activeDistanceMeters) && styles.filterButtonActive,
              ]}
              onPress={openFilterSheet}
            >
              <Text
                style={[
                  styles.filterText,
                  (activeFilters.length > 0 || activeDistanceMeters) && styles.filterTextActive,
                ]}
              >
                {activeDistanceMeters
                  ? distanceLabel(activeDistanceMeters)
                  : activeFilters.length > 0
                    ? `${activeFilters.length}`
                    : 'Filter'}
              </Text>
            </Pressable>
          </View>

          {activeFilters.length > 0 || activeDistanceMeters ? (
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.activeFilterChips}
              style={styles.activeFilterScroll}
            >
              {activeDistanceMeters ? (
                <Pressable
                  style={styles.activeFilterChip}
                  onPress={() => {
                    setActiveDistanceMeters(null);
                    setPendingDistanceMeters(null);
                    setSelectedVendorId(null);
                  }}
                >
                  <Text style={styles.activeFilterChipText}>{distanceLabel(activeDistanceMeters)}</Text>
                  <Text style={styles.activeFilterChipClose}>X</Text>
                </Pressable>
              ) : null}
              {activeFilters.map((filterKey) => (
                <Pressable
                  key={filterKey}
                  style={styles.activeFilterChip}
                  onPress={() => {
                    const nextFilters = activeFilters.filter((item) => item !== filterKey);
                    setActiveFilters(nextFilters);
                    setPendingFilters(nextFilters);
                    setSelectedVendorId(null);
                  }}
                >
                  <Text style={styles.activeFilterChipText}>{filterKey}</Text>
                  <Text style={styles.activeFilterChipClose}>X</Text>
                </Pressable>
              ))}
            </ScrollView>
          ) : null}

          {!normalizedSearch && filteredVendors.length === 0 ? (
            <View style={styles.radiusEmptyState}>
              <Text style={styles.radiusEmptyTitle}>Geen vendors gevonden binnen deze afstand</Text>
              <Text style={styles.radiusEmptyCopy}>Probeer een grotere zoekradius</Text>
            </View>
          ) : null}

          {normalizedSearch ? (
            <View style={styles.searchResults}>
              {searchResults.length > 0 ? (
                searchResults.map((result) => (
                  <Pressable
                    key={result.record.vendor.id}
                    style={styles.searchResultRow}
                    onPress={() => {
                      Keyboard.dismiss();
                      setSelectedVendorId(result.record.vendor.id);
                      if (result.record.latestLocation) {
                        setRegion({
                          latitude: result.record.latestLocation.latitude,
                          longitude: result.record.latestLocation.longitude,
                          latitudeDelta: 0.015,
                          longitudeDelta: 0.015,
                        });
                      }
                    }}
                  >
                    <View style={styles.searchResultTextWrap}>
                      <Text style={styles.searchResultName}>
                        {result.record.vendor.businessName}
                      </Text>
                      <Text style={styles.searchResultMeta}>
                        {result.record.vendor.category} · {result.record.vendor.distanceKm} km away
                      </Text>
                      {result.matchedProductName ? (
                        <Text style={styles.searchResultMatch}>
                          Product: {result.matchedProductName}
                        </Text>
                      ) : null}
                      <Text style={styles.searchResultStatus}>
                        {result.record.vendor.liveStatus === 'live' ? 'Live now' : 'Offline'}
                      </Text>
                    </View>
                    <Text style={styles.searchResultAction}>Show</Text>
                  </Pressable>
                ))
              ) : (
                <View style={styles.searchResultEmpty}>
                  <Text style={styles.searchResultEmptyTitle}>Geen resultaten gevonden</Text>
                  <Text style={styles.searchResultEmptyText}>Probeer een andere zoekterm</Text>
                </View>
              )}
            </View>
          ) : null}

          {selectedVendor ? (
            <View style={styles.previewCard}>
              <View style={styles.previewHeader}>
                <View style={styles.previewIdentity}>
                  <Text style={styles.previewName}>{selectedVendor.vendor.businessName}</Text>
                  <Text style={styles.previewMeta}>
                    {selectedVendor.vendor.category} · {selectedVendor.vendor.distanceKm} km away
                  </Text>
                </View>
                <View style={styles.previewLiveBadge}>
                  <Text style={styles.previewLiveText}>LIVE</Text>
                </View>
              </View>

              <Text style={styles.previewCopy}>{selectedVendor.vendor.description}</Text>

              <View style={styles.previewActions}>
                <Pressable
                  style={styles.previewButtonPrimary}
                  onPress={() =>
                    navigation.navigate('Vendors', {
                      screen: 'VendorDetail',
                      params: { vendorId: selectedVendor.vendor.id },
                    })
                  }
                >
                  <Text style={styles.previewButtonPrimaryText}>Open profile</Text>
                </Pressable>
                <Pressable
                  style={styles.previewButtonSecondary}
                  onPress={() => setSelectedVendorId(null)}
                >
                  <Text style={styles.previewButtonSecondaryText}>Close</Text>
                </Pressable>
              </View>
            </View>
          ) : null}

          {isFilterSheetOpen ? (
            <View style={styles.sheetOverlay}>
              <Pressable style={styles.sheetBackdrop} onPress={() => setIsFilterSheetOpen(false)} />
              <View style={styles.sheet}>
                <View style={styles.sheetHandle} />
                <Text style={styles.sheetTitle}>Filter by vendor type</Text>
                <Text style={styles.sheetCopy}>
                  Choose one or more categories to narrow what appears on the map.
                </Text>

                <View style={styles.sheetSection}>
                  <Text style={styles.sheetSectionTitle}>Distance</Text>
                  <View style={styles.sheetChipWrap}>
                    {distanceOptions.map((distanceOption) => {
                      const isSelected = pendingDistanceMeters === distanceOption;

                      return (
                        <Pressable
                          key={distanceOption}
                          style={[styles.sheetChip, isSelected && styles.sheetChipSelected]}
                          onPress={() =>
                            setPendingDistanceMeters((current) =>
                              current === distanceOption ? null : distanceOption
                            )
                          }
                        >
                          <View style={styles.sheetChipInner}>
                            <Text style={styles.sheetChipIcon}>📍</Text>
                            <Text
                              style={[
                                styles.sheetChipText,
                                isSelected && styles.sheetChipTextSelected,
                              ]}
                            >
                              {distanceLabel(distanceOption)}
                            </Text>
                          </View>
                        </Pressable>
                      );
                    })}
                  </View>
                  {!hasUserLocation ? (
                    <Text style={styles.sheetHelperText}>
                      Give location permission to use distance filters and map radius.
                    </Text>
                  ) : null}
                </View>

                <View style={styles.sheetSection}>
                  <Text style={styles.sheetSectionTitle}>Vendor type</Text>
                <View style={styles.sheetChipWrap}>
                  {filterOptions.map((filterKey) => {
                    const isSelected = pendingFilters.includes(filterKey);

                    return (
                      <Pressable
                        key={filterKey}
                        style={[styles.sheetChip, isSelected && styles.sheetChipSelected]}
                        onPress={() => togglePendingFilter(filterKey)}
                      >
                        <View style={styles.sheetChipInner}>
                          <Text style={styles.sheetChipIcon}>{filterIcons[filterKey]}</Text>
                          <Text
                            style={[
                              styles.sheetChipText,
                              isSelected && styles.sheetChipTextSelected,
                            ]}
                          >
                            {filterKey}
                          </Text>
                        </View>
                      </Pressable>
                    );
                  })}
                </View>
                </View>

                <View style={styles.sheetActions}>
                  <Pressable style={styles.sheetResetButton} onPress={resetFilters}>
                    <Text style={styles.sheetResetText}>Reset</Text>
                  </Pressable>
                  <Pressable style={styles.sheetApplyButton} onPress={applyFilters}>
                    <Text style={styles.sheetApplyText}>
                      Apply ({pendingFilteredVendors.length})
                    </Text>
                  </Pressable>
                </View>
              </View>
            </View>
          ) : null}
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: palette.ink,
  },
  container: {
    flex: 1,
    backgroundColor: '#09121E',
  },
  mapSurface: {
    flex: 1,
    position: 'relative',
    overflow: 'hidden',
    backgroundColor: '#08121D',
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  vendorMarkerWrap: {
    alignItems: 'center',
  },
  vendorMarker: {
    minWidth: 42,
    height: 42,
    paddingHorizontal: 10,
    borderRadius: 21,
    backgroundColor: '#FFF7ED',
    borderWidth: 2,
    borderColor: '#F97316',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 6,
  },
  vendorMarkerText: {
    color: '#9A3412',
    fontSize: 18,
    fontWeight: '800',
  },
  vendorMarkerCocero: {
    backgroundColor: '#ECFDF5',
    borderColor: '#10B981',
  },
  vendorMarkerTextCocero: {
    color: '#047857',
  },
  vendorMarkerTruck: {
    backgroundColor: '#FFF1F2',
    borderColor: '#DC2626',
  },
  vendorMarkerTextTruck: {
    color: '#991B1B',
  },
  vendorMarkerPointer: {
    marginTop: -1,
    width: 12,
    height: 12,
    backgroundColor: '#FFF7ED',
    borderRightWidth: 2,
    borderBottomWidth: 2,
    borderColor: '#F97316',
    transform: [{ rotate: '45deg' }],
  },
  vendorMarkerPointerCocero: {
    backgroundColor: '#ECFDF5',
    borderColor: '#10B981',
  },
  vendorMarkerPointerTruck: {
    backgroundColor: '#FFF1F2',
    borderColor: '#DC2626',
  },
  searchRow: {
    position: 'absolute',
    top: 12,
    left: 20,
    right: 20,
    zIndex: 3,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  searchBar: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 999,
    paddingHorizontal: 18,
    paddingVertical: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  searchInput: {
    flex: 1,
    color: '#111827',
    fontSize: 15,
    fontWeight: '500',
  },
  clearSearchButton: {
    width: 24,
    height: 24,
    borderRadius: 999,
    backgroundColor: '#E5E7EB',
    alignItems: 'center',
    justifyContent: 'center',
  },
  clearSearchButtonText: {
    color: '#4B5563',
    fontSize: 12,
    fontWeight: '900',
  },
  filterButton: {
    width: 58,
    height: 58,
    borderRadius: 999,
    backgroundColor: palette.panel,
    alignItems: 'center',
    justifyContent: 'center',
  },
  filterButtonActive: {
    backgroundColor: palette.mint,
  },
  filterText: {
    color: palette.mint,
    fontSize: 11,
    fontWeight: '800',
    textTransform: 'uppercase',
  },
  filterTextActive: {
    color: '#0F172A',
  },
  activeFilterScroll: {
    position: 'absolute',
    top: 78,
    left: 20,
    right: 20,
    zIndex: 3,
  },
  activeFilterChips: {
    gap: 8,
    paddingRight: 20,
  },
  activeFilterChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: 'rgba(15, 28, 46, 0.92)',
    borderRadius: 999,
    paddingHorizontal: 14,
    paddingVertical: 10,
  },
  activeFilterChipText: {
    color: palette.cloud,
    fontSize: 12,
    fontWeight: '800',
  },
  activeFilterChipClose: {
    color: palette.mint,
    fontSize: 11,
    fontWeight: '900',
  },
  searchResults: {
    position: 'absolute',
    top: 126,
    left: 20,
    right: 20,
    zIndex: 3,
    backgroundColor: 'rgba(255,255,255,0.97)',
    borderRadius: 22,
    paddingVertical: 8,
    overflow: 'hidden',
  },
  searchResultRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  searchResultTextWrap: {
    flex: 1,
  },
  searchResultName: {
    color: '#111827',
    fontSize: 14,
    fontWeight: '800',
  },
  searchResultMeta: {
    marginTop: 3,
    color: '#64748B',
    fontSize: 12,
  },
  searchResultAction: {
    color: '#0F766E',
    fontSize: 12,
    fontWeight: '800',
  },
  searchResultMatch: {
    marginTop: 4,
    color: '#0F172A',
    fontSize: 12,
    fontWeight: '700',
  },
  searchResultStatus: {
    marginTop: 4,
    color: '#166534',
    fontSize: 12,
    fontWeight: '700',
  },
  searchResultEmpty: {
    paddingHorizontal: 16,
    paddingVertical: 14,
  },
  searchResultEmptyTitle: {
    color: '#111827',
    fontSize: 13,
    fontWeight: '800',
  },
  searchResultEmptyText: {
    marginTop: 4,
    color: '#64748B',
    fontSize: 13,
    fontWeight: '700',
  },
  radiusEmptyState: {
    position: 'absolute',
    left: 20,
    right: 20,
    bottom: 20,
    zIndex: 3,
    backgroundColor: 'rgba(15, 28, 46, 0.96)',
    borderRadius: 24,
    padding: 16,
  },
  radiusEmptyTitle: {
    color: palette.cloud,
    fontSize: 16,
    fontWeight: '800',
  },
  radiusEmptyCopy: {
    marginTop: 6,
    color: '#B7C4D8',
    fontSize: 13,
    lineHeight: 20,
  },
  previewCard: {
    position: 'absolute',
    left: 20,
    right: 20,
    bottom: 20,
    zIndex: 3,
    backgroundColor: 'rgba(15, 28, 46, 0.96)',
    borderRadius: 24,
    padding: 16,
    gap: 10,
  },
  previewHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
  },
  previewIdentity: {
    flex: 1,
  },
  previewName: {
    color: palette.cloud,
    fontSize: 18,
    fontWeight: '800',
  },
  previewMeta: {
    marginTop: 4,
    color: '#B7C4D8',
    fontSize: 12,
    fontWeight: '700',
  },
  previewLiveBadge: {
    alignSelf: 'flex-start',
    backgroundColor: '#DCFCE7',
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  previewLiveText: {
    color: '#166534',
    fontSize: 11,
    fontWeight: '800',
  },
  previewCopy: {
    color: '#D6E2F0',
    fontSize: 13,
    lineHeight: 20,
  },
  previewActions: {
    flexDirection: 'row',
    gap: 10,
  },
  previewButtonPrimary: {
    flex: 1,
    backgroundColor: palette.mint,
    borderRadius: 999,
    paddingVertical: 11,
    alignItems: 'center',
  },
  previewButtonPrimaryText: {
    color: '#0F172A',
    fontSize: 12,
    fontWeight: '800',
  },
  previewButtonSecondary: {
    backgroundColor: 'rgba(255,255,255,0.10)',
    borderRadius: 999,
    paddingHorizontal: 16,
    paddingVertical: 11,
    alignItems: 'center',
  },
  previewButtonSecondaryText: {
    color: palette.cloud,
    fontSize: 12,
    fontWeight: '800',
  },
  sheetOverlay: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 5,
    justifyContent: 'flex-end',
  },
  sheetBackdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(3, 8, 18, 0.48)',
  },
  sheet: {
    backgroundColor: '#F8FAFC',
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    paddingHorizontal: 20,
    paddingTop: 12,
    paddingBottom: 28,
    gap: 16,
  },
  sheetHandle: {
    alignSelf: 'center',
    width: 48,
    height: 5,
    borderRadius: 999,
    backgroundColor: '#CBD5E1',
  },
  sheetTitle: {
    color: '#0F172A',
    fontSize: 22,
    fontWeight: '800',
  },
  sheetCopy: {
    color: '#475569',
    fontSize: 14,
    lineHeight: 21,
  },
  sheetSection: {
    gap: 10,
  },
  sheetSectionTitle: {
    color: '#0F172A',
    fontSize: 15,
    fontWeight: '800',
  },
  sheetChipWrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  sheetHelperText: {
    color: '#64748B',
    fontSize: 12,
    lineHeight: 18,
  },
  sheetChip: {
    borderRadius: 999,
    borderWidth: 1,
    borderColor: '#CBD5E1',
    paddingHorizontal: 14,
    paddingVertical: 10,
    backgroundColor: '#FFFFFF',
  },
  sheetChipInner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  sheetChipIcon: {
    fontSize: 15,
  },
  sheetChipSelected: {
    backgroundColor: '#DCFCE7',
    borderColor: '#22C55E',
  },
  sheetChipText: {
    color: '#334155',
    fontSize: 13,
    fontWeight: '700',
  },
  sheetChipTextSelected: {
    color: '#166534',
  },
  sheetActions: {
    flexDirection: 'row',
    gap: 10,
  },
  sheetResetButton: {
    flex: 1,
    borderRadius: 999,
    backgroundColor: '#E2E8F0',
    paddingVertical: 14,
    alignItems: 'center',
  },
  sheetResetText: {
    color: '#334155',
    fontSize: 13,
    fontWeight: '800',
  },
  sheetApplyButton: {
    flex: 1,
    borderRadius: 999,
    backgroundColor: palette.ink,
    paddingVertical: 14,
    alignItems: 'center',
  },
  sheetApplyText: {
    color: palette.cloud,
    fontSize: 13,
    fontWeight: '800',
  },
});
