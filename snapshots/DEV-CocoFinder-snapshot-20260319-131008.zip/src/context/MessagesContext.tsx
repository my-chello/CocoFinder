import { createContext, ReactNode, useCallback, useContext, useMemo, useState } from 'react';
import { chatMessages, conversationSummaries } from '../data/mockMessages';
import { vendorTabRecords } from '../data/mockVendors';
import type { ChatMessage, ConversationSummary } from '../types/messages';

type MessagesContextValue = {
  conversations: ConversationSummary[];
  getConversationById: (conversationId: string) => ConversationSummary | undefined;
  getMessagesForConversation: (conversationId: string) => ChatMessage[];
  openConversationForVendor: (vendorId: string) => string;
  sendMessage: (conversationId: string, body: string) => void;
  markConversationRead: (conversationId: string) => void;
  deleteConversation: (conversationId: string) => void;
};

const MessagesContext = createContext<MessagesContextValue | null>(null);

function findVendorRecord(vendorId: string) {
  return vendorTabRecords.find((record) => record.vendor.id === vendorId);
}

function buildConversationSummary(vendorId: string): ConversationSummary {
  const vendorRecord = findVendorRecord(vendorId);

  if (!vendorRecord) {
    throw new Error(`Vendor ${vendorId} not found for conversation`);
  }

  return {
    id: `conversation-${vendorId}`,
    vendorId,
    customerUserId: 'user-customer-alex',
    vendorName: vendorRecord.vendor.businessName,
    vendorCategory: vendorRecord.vendor.category,
    vendorSymbol: vendorRecord.vendor.imageSymbol ?? vendorRecord.vendor.imageHint,
    lastMessagePreview: '',
    lastMessageAt: '',
    lastMessageSortMinutesAgo: Number.MAX_SAFE_INTEGER,
    unreadCount: 0,
    isVendorLive: vendorRecord.vendor.liveStatus === 'live',
    isVisibleInInbox: false,
  };
}

export function MessagesProvider({ children }: { children: ReactNode }) {
  const [conversations, setConversations] = useState<ConversationSummary[]>(conversationSummaries);
  const [messages, setMessages] = useState<ChatMessage[]>(chatMessages);

  const sortedVisibleConversations = useMemo(
    () =>
      [...conversations]
        .filter((conversation) => conversation.isVisibleInInbox)
        .sort((left, right) => left.lastMessageSortMinutesAgo - right.lastMessageSortMinutesAgo),
    [conversations]
  );

  const getConversationById = useCallback((conversationId: string) => {
    return conversations.find((conversation) => conversation.id === conversationId);
  }, [conversations]);

  const getMessagesForConversation = useCallback((conversationId: string) => {
    return messages.filter((message) => message.conversationId === conversationId);
  }, [messages]);

  const openConversationForVendor = useCallback((vendorId: string) => {
    const existingConversation = conversations.find((conversation) => conversation.vendorId === vendorId);

    if (existingConversation) {
      return existingConversation.id;
    }

    const nextConversation = buildConversationSummary(vendorId);

    setConversations((current) => [nextConversation, ...current]);

    return nextConversation.id;
  }, [conversations]);

  const sendMessage = useCallback((conversationId: string, body: string) => {
    const trimmedBody = body.trim();

    if (!trimmedBody) {
      return;
    }

    const nextMessage: ChatMessage = {
      id: `message-local-${Date.now()}`,
      conversationId,
      senderRole: 'customer',
      senderName: 'Alex Customer',
      body: trimmedBody,
      sentAt: 'Just now',
    };

    setMessages((current) => [...current, nextMessage]);
    setConversations((current) =>
      current.map((conversation) =>
        conversation.id === conversationId
          ? {
              ...conversation,
              lastMessagePreview: trimmedBody,
              lastMessageAt: 'Just now',
              lastMessageSortMinutesAgo: 0,
              unreadCount: 0,
              isVisibleInInbox: true,
            }
          : {
              ...conversation,
              lastMessageSortMinutesAgo:
                conversation.lastMessageSortMinutesAgo === Number.MAX_SAFE_INTEGER
                  ? Number.MAX_SAFE_INTEGER
                  : conversation.lastMessageSortMinutesAgo + 1,
            }
      )
    );
  }, []);

  const markConversationRead = useCallback((conversationId: string) => {
    setConversations((current) =>
      current.map((conversation) =>
        conversation.id === conversationId
          ? {
              ...conversation,
              unreadCount: 0,
            }
          : conversation
      )
    );
  }, []);

  const deleteConversation = useCallback((conversationId: string) => {
    setConversations((current) =>
      current.map((conversation) =>
        conversation.id === conversationId
          ? {
              ...conversation,
              isVisibleInInbox: false,
            }
          : conversation
      )
    );
  }, []);

  const value = useMemo(
    () => ({
      conversations: sortedVisibleConversations,
      getConversationById,
      getMessagesForConversation,
      openConversationForVendor,
      sendMessage,
      markConversationRead,
      deleteConversation,
    }),
    [
      deleteConversation,
      getConversationById,
      getMessagesForConversation,
      markConversationRead,
      openConversationForVendor,
      sendMessage,
      sortedVisibleConversations,
    ]
  );

  return (
    <MessagesContext.Provider value={value}>
      {children}
    </MessagesContext.Provider>
  );
}

export function useMessages() {
  const context = useContext(MessagesContext);

  if (!context) {
    throw new Error('useMessages must be used within a MessagesProvider');
  }

  return context;
}
